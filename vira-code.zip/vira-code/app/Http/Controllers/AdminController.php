<?php
/**
 * Admin Controller
 *
 * @package ViraCode
 */

namespace ViraCode\Http\Controllers;

use ViraCode\Models\SnippetModel;
use ViraCode\Services\SnippetExecutor;

if (!defined("ABSPATH")) {
    exit();
}

/**
 * AdminController Class
 *
 * Handles admin interface rendering and AJAX requests.
 */
class AdminController
{
    /**
     * Snippet model instance.
     *
     * @var SnippetModel
     */
    protected $model;

    /**
     * Snippet executor instance.
     *
     * @var SnippetExecutor
     */
    protected $executor;

    /**
     * Constructor.
     */
    public function __construct()
    {
        $this->model = new SnippetModel();
        $this->executor = new SnippetExecutor();
    }

    /**
     * Display snippets list page.
     *
     * @return void
     */
    public function index()
    {
        // Check user capability.
        if (!\ViraCode\vira_code_user_can_manage()) {
            wp_die(
                esc_html__(
                    "You do not have permission to access this page.",
                    "vira-code",
                ),
            );
        }

        // Get all snippets.
        $snippets = $this->model->getAll();

        // Get statistics.
        $stats = [
            "total" => $this->model->count(),
            "active" => $this->model->count(["status" => "active"]),
            "inactive" => $this->model->count(["status" => "inactive"]),
            "error" => $this->model->count(["status" => "error"]),
        ];

        // Render view.
        \ViraCode\vira_code_view("snippets-list", [
            "snippets" => $snippets,
            "stats" => $stats,
        ]);
    }

    /**
     * Display create snippet page.
     *
     * @return void
     */
    public function create()
    {
        // Check user capability.
        if (!\ViraCode\vira_code_user_can_manage()) {
            wp_die(
                esc_html__(
                    "You do not have permission to access this page.",
                    "vira-code",
                ),
            );
        }

        // Check if editing existing snippet.
        $snippet_id = isset($_GET["id"]) ? absint($_GET["id"]) : 0;
        $snippet = null;

        if ($snippet_id > 0) {
            $snippet = $this->model->getById($snippet_id);
            if (!$snippet) {
                wp_die(esc_html__("Snippet not found.", "vira-code"));
            }
        }

        // Render view.
        \ViraCode\vira_code_view("snippet-editor", [
            "snippet" => $snippet,
            "is_new" => null === $snippet,
        ]);
    }

    /**
     * Display settings page.
     *
     * @return void
     */
    public function settings()
    {
        // Check user capability.
        if (!\ViraCode\vira_code_user_can_manage()) {
            wp_die(
                esc_html__(
                    "You do not have permission to access this page.",
                    "vira-code",
                ),
            );
        }

        // Handle form submission.
        if (isset($_POST["vira_code_settings_nonce"])) {
            $this->saveSettings();
        }

        // Get current settings.
        $settings = [
            "safe_mode" => \ViraCode\vira_code_is_safe_mode(),
        ];

        // Render view.
        \ViraCode\vira_code_view("settings", [
            "settings" => $settings,
        ]);
    }

    /**
     * Display logs page.
     *
     * @return void
     */
    public function logs()
    {
        // Check user capability.
        if (!\ViraCode\vira_code_user_can_manage()) {
            wp_die(
                esc_html__(
                    "You do not have permission to access this page.",
                    "vira-code",
                ),
            );
        }

        // Get execution logs.
        $logs = \ViraCode\vira_code_get_logs();

        // Reverse to show newest first.
        $logs = array_reverse($logs);

        // Render view.
        \ViraCode\vira_code_view("logs", [
            "logs" => $logs,
        ]);
    }

    /**
     * Display library page.
     *
     * @return void
     */
    public function library()
    {
        // Check user capability.
        if (!\ViraCode\vira_code_user_can_manage()) {
            wp_die(
                esc_html__(
                    "You do not have permission to access this page.",
                    "vira-code",
                ),
            );
        }

        // Get library snippets.
        $snippets = $this->getLibrarySnippets();

        // Render view.
        \ViraCode\vira_code_view("library", [
            "snippets" => $snippets,
        ]);
    }

    /**
     * Get library snippets.
     *
     * @return array
     */
    protected function getLibrarySnippets()
    {
        $snippets = [
            [
                "id" => "wc-hide-shipping-when-free",
                "title" =>
                    "Hide Other Shipping Methods When Free Shipping Available",
                "description" =>
                    "Automatically hide all other shipping methods when free shipping is available in WooCommerce cart.",
                "category" => "WooCommerce",
                "type" => "php",
                "scope" => "frontend",
                "code" => "// Hide shipping rates when free shipping is available
add_filter('woocommerce_package_rates', function(\$rates) {
    \$free = array();
    foreach (\$rates as \$rate_id => \$rate) {
        if ('free_shipping' === \$rate->method_id) {
            \$free[\$rate_id] = \$rate;
            break;
        }
    }
    return !empty(\$free) ? \$free : \$rates;
}, 100);",
                "tags" => "shipping, woocommerce, cart",
                "icon" => "dashicons-cart",
            ],
            [
                "id" => "wc-custom-add-to-cart-text",
                "title" => "Change Add to Cart Button Text",
                "description" =>
                    'Customize the "Add to Cart" button text for different product types in WooCommerce.',
                "category" => "WooCommerce",
                "type" => "php",
                "scope" => "frontend",
                "code" => "// Change Add to Cart button text
add_filter('woocommerce_product_single_add_to_cart_text', function(\$text) {
    return __('Buy Now', 'woocommerce');
});

add_filter('woocommerce_product_add_to_cart_text', function(\$text) {
    global \$product;
    if (\$product->is_type('simple')) {
        return __('Purchase', 'woocommerce');
    }
    return \$text;
});",
                "tags" => "button, text, woocommerce",
                "icon" => "dashicons-button",
            ],
            [
                "id" => "wc-remove-product-tabs",
                "title" => "Remove Product Tabs",
                "description" =>
                    "Remove specific tabs from WooCommerce product pages like reviews, description, or additional information.",
                "category" => "WooCommerce",
                "type" => "php",
                "scope" => "frontend",
                "code" => "// Remove product tabs
add_filter('woocommerce_product_tabs', function(\$tabs) {
    // Remove the reviews tab
    unset(\$tabs['reviews']);

    // Remove the description tab
    // unset(\$tabs['description']);

    // Remove the additional information tab
    // unset(\$tabs['additional_information']);

    return \$tabs;
}, 98);",
                "tags" => "tabs, product, woocommerce",
                "icon" => "dashicons-archive",
            ],
            [
                "id" => "wc-minimum-order-amount",
                "title" => "Set Minimum Order Amount",
                "description" =>
                    "Set a minimum order amount required before customers can checkout in WooCommerce.",
                "category" => "WooCommerce",
                "type" => "php",
                "scope" => "frontend",
                "code" => "// Set minimum order amount
add_action('woocommerce_checkout_process', function() {
    \$minimum = 50; // Set your minimum amount
    \$cart_total = WC()->cart->total;

    if (\$cart_total < \$minimum) {
        wc_add_notice(
            sprintf(
                'Minimum order amount is %s. Current total: %s',
                wc_price(\$minimum),
                wc_price(\$cart_total)
            ),
            'error'
        );
    }
});",
                "tags" => "checkout, cart, minimum, woocommerce",
                "icon" => "dashicons-money-alt",
            ],
            [
                "id" => "wc-custom-checkout-fields",
                "title" => "Add Custom Checkout Field",
                "description" =>
                    "Add a custom field to the WooCommerce checkout page and save it with the order.",
                "category" => "WooCommerce",
                "type" => "php",
                "scope" => "frontend",
                "code" => "// Add custom checkout field
add_action('woocommerce_after_order_notes', function(\$checkout) {
    echo '<div id=\"custom_checkout_field\"><h3>' . __('Additional Information') . '</h3>';

    woocommerce_form_field('gift_message', array(
        'type'        => 'textarea',
        'class'       => array('form-row-wide'),
        'label'       => __('Gift Message'),
        'placeholder' => __('Enter your gift message here...'),
    ), \$checkout->get_value('gift_message'));

    echo '</div>';
});

// Save custom checkout field
add_action('woocommerce_checkout_update_order_meta', function(\$order_id) {
    if (!empty(\$_POST['gift_message'])) {
        update_post_meta(\$order_id, 'gift_message', sanitize_text_field(\$_POST['gift_message']));
    }
});",
                "tags" => "checkout, fields, custom, woocommerce",
                "icon" => "dashicons-feedback",
            ],
        ];

        return apply_filters("vira_code/library_snippets", $snippets);
    }

    /**
     * Validate snippet via AJAX (for testing new snippets).
     *
     * @return void
     */
    public function validateSnippet()
    {
        // Verify nonce.
        check_ajax_referer(\ViraCode\vira_code_nonce_action(), "nonce");

        // Check user capability.
        if (!\ViraCode\vira_code_user_can_manage()) {
            wp_send_json_error([
                "message" => __("Permission denied.", "vira-code"),
            ]);
        }

        // Get snippet data.
        $code = isset($_POST["code"]) ? wp_unslash($_POST["code"]) : "";
        $type = isset($_POST["type"])
            ? sanitize_text_field(wp_unslash($_POST["type"]))
            : "php";

        // Validate required fields.
        if (empty($code)) {
            wp_send_json_error([
                "message" => __("Code is required.", "vira-code"),
                "error" => __("No code provided for validation.", "vira-code"),
            ]);
        }

        // Only validate PHP snippets.
        if ("php" !== $type) {
            wp_send_json_success([
                "message" => __(
                    "Validation is only available for PHP snippets.",
                    "vira-code",
                ),
            ]);
        }

        // Test the snippet.
        $test_result = $this->executor->test([
            "id" => 0,
            "code" => $code,
            "type" => $type,
        ]);

        if ($test_result["valid"]) {
            wp_send_json_success([
                "message" => __(
                    "PHP validation passed! No syntax errors found.",
                    "vira-code",
                ),
            ]);
        } else {
            $error_message = !empty($test_result["errors"])
                ? implode("\n", $test_result["errors"])
                : __("Unknown validation error.", "vira-code");

            wp_send_json_error([
                "message" => __("PHP validation failed.", "vira-code"),
                "error" => $error_message,
            ]);
        }
    }

    /**
     * Save snippet via AJAX.
     *
     * @return void
     */
    public function saveSnippet()
    {
        // Verify nonce.
        check_ajax_referer(\ViraCode\vira_code_nonce_action(), "nonce");

        // Check user capability.
        if (!\ViraCode\vira_code_user_can_manage()) {
            wp_send_json_error([
                "message" => __("Permission denied.", "vira-code"),
            ]);
        }

        // Get snippet data.
        $snippet_id = isset($_POST["id"]) ? absint($_POST["id"]) : 0;
        $data = [
            "title" => isset($_POST["title"])
                ? sanitize_text_field(wp_unslash($_POST["title"]))
                : "",
            "description" => isset($_POST["description"])
                ? sanitize_textarea_field(wp_unslash($_POST["description"]))
                : "",
            "code" => isset($_POST["code"]) ? wp_unslash($_POST["code"]) : "",
            "type" => isset($_POST["type"])
                ? sanitize_text_field(wp_unslash($_POST["type"]))
                : "php",
            "scope" => isset($_POST["scope"])
                ? sanitize_text_field(wp_unslash($_POST["scope"]))
                : "frontend",
            "status" => isset($_POST["status"])
                ? sanitize_text_field(wp_unslash($_POST["status"]))
                : "inactive",
            "tags" => isset($_POST["tags"])
                ? sanitize_text_field(wp_unslash($_POST["tags"]))
                : "",
            "category" => isset($_POST["category"])
                ? sanitize_text_field(wp_unslash($_POST["category"]))
                : "",
            "priority" => isset($_POST["priority"])
                ? absint($_POST["priority"])
                : 10,
        ];

        // Validate required fields.
        if (empty($data["title"]) || empty($data["code"])) {
            wp_send_json_error([
                "message" => __("Title and code are required.", "vira-code"),
            ]);
        }

        // Validate snippet type.
        $valid_types = array_keys(\ViraCode\vira_code_snippet_types());
        if (!in_array($data["type"], $valid_types, true)) {
            wp_send_json_error([
                "message" => __("Invalid snippet type.", "vira-code"),
            ]);
        }

        // Validate snippet scope.
        $valid_scopes = array_keys(\ViraCode\vira_code_snippet_scopes());
        if (!in_array($data["scope"], $valid_scopes, true)) {
            wp_send_json_error([
                "message" => __("Invalid snippet scope.", "vira-code"),
            ]);
        }

        // Test PHP snippets before saving.
        if ("php" === $data["type"]) {
            $test_result = $this->executor->test(
                array_merge(["id" => 0], $data),
            );
            if (!$test_result["valid"]) {
                wp_send_json_error([
                    "message" => __(
                        "PHP validation failed. Please check your code.",
                        "vira-code",
                    ),
                    "errors" => $test_result["errors"],
                ]);
            }
        }

        // Save snippet.
        if ($snippet_id > 0) {
            // Update existing snippet.
            $result = $this->model->update($snippet_id, $data);
            if ($result) {
                wp_send_json_success([
                    "message" => __(
                        "Snippet updated successfully!",
                        "vira-code",
                    ),
                    "snippet_id" => $snippet_id,
                ]);
            } else {
                wp_send_json_error([
                    "message" => __("Failed to update snippet.", "vira-code"),
                ]);
            }
        } else {
            // Create new snippet.
            $result = $this->model->create($data);
            if ($result) {
                wp_send_json_success([
                    "message" => __(
                        "Snippet created successfully!",
                        "vira-code",
                    ),
                    "snippet_id" => $result,
                ]);
            } else {
                wp_send_json_error([
                    "message" => __("Failed to create snippet.", "vira-code"),
                ]);
            }
        }
    }

    /**
     * Delete snippet via AJAX.
     *
     * @return void
     */
    public function deleteSnippet()
    {
        // Verify nonce.
        check_ajax_referer(\ViraCode\vira_code_nonce_action(), "nonce");

        // Check user capability.
        if (!\ViraCode\vira_code_user_can_manage()) {
            wp_send_json_error([
                "message" => __("Permission denied.", "vira-code"),
            ]);
        }

        // Get snippet ID.
        $snippet_id = isset($_POST["id"]) ? absint($_POST["id"]) : 0;

        if ($snippet_id <= 0) {
            wp_send_json_error([
                "message" => __("Invalid snippet ID.", "vira-code"),
            ]);
        }

        // Delete snippet.
        $result = $this->model->delete($snippet_id);

        if ($result) {
            wp_send_json_success([
                "message" => __("Snippet deleted successfully!", "vira-code"),
            ]);
        } else {
            wp_send_json_error([
                "message" => __("Failed to delete snippet.", "vira-code"),
            ]);
        }
    }

    /**
     * Toggle snippet status via AJAX.
     *
     * @return void
     */
    public function toggleSnippet()
    {
        // Verify nonce.
        check_ajax_referer(\ViraCode\vira_code_nonce_action(), "nonce");

        // Check user capability.
        if (!\ViraCode\vira_code_user_can_manage()) {
            wp_send_json_error([
                "message" => __("Permission denied.", "vira-code"),
            ]);
        }

        // Get snippet ID.
        $snippet_id = isset($_POST["id"]) ? absint($_POST["id"]) : 0;

        if ($snippet_id <= 0) {
            wp_send_json_error([
                "message" => __("Invalid snippet ID.", "vira-code"),
            ]);
        }

        // Toggle status.
        $result = $this->model->toggleStatus($snippet_id);

        if ($result) {
            $snippet = $this->model->getById($snippet_id);
            wp_send_json_success([
                "message" => __("Snippet status updated!", "vira-code"),
                "status" => $snippet["status"],
            ]);
        } else {
            wp_send_json_error([
                "message" => __(
                    "Failed to update snippet status.",
                    "vira-code",
                ),
            ]);
        }
    }

    /**
     * Get statistics via AJAX.
     *
     * @return void
     */
    public function getStatistics()
    {
        // Verify nonce.
        check_ajax_referer(\ViraCode\vira_code_nonce_action(), "nonce");

        // Check user capability.
        if (!\ViraCode\vira_code_user_can_manage()) {
            wp_send_json_error([
                "message" => __("Permission denied.", "vira-code"),
            ]);
        }

        // Get statistics.
        $stats = [
            "total" => $this->model->count(),
            "active" => $this->model->count(["status" => "active"]),
            "inactive" => $this->model->count(["status" => "inactive"]),
            "error" => $this->model->count(["status" => "error"]),
        ];

        wp_send_json_success([
            "stats" => $stats,
        ]);
    }

    /**
     * Toggle safe mode via AJAX.
     *
     * @return void
     */
    public function toggleSafeMode()
    {
        // Verify nonce.
        check_ajax_referer(\ViraCode\vira_code_nonce_action(), "nonce");

        // Check user capability.
        if (!\ViraCode\vira_code_user_can_manage()) {
            wp_send_json_error([
                "message" => __("Permission denied.", "vira-code"),
            ]);
        }

        $current_safe_mode = \ViraCode\vira_code_is_safe_mode();

        if ($current_safe_mode) {
            $result = \ViraCode\vira_code_disable_safe_mode();
            $message = __(
                "Safe mode disabled. Snippets will now execute normally.",
                "vira-code",
            );
        } else {
            $result = \ViraCode\vira_code_enable_safe_mode();
            $message = __(
                "Safe mode enabled. All snippets are now disabled.",
                "vira-code",
            );
        }

        if ($result) {
            wp_send_json_success([
                "message" => $message,
                "safe_mode" => !$current_safe_mode,
            ]);
        } else {
            wp_send_json_error([
                "message" => __("Failed to toggle safe mode.", "vira-code"),
            ]);
        }
    }

    /**
     * Clear logs via AJAX.
     *
     * @return void
     */
    public function clearLogs()
    {
        // Verify nonce.
        check_ajax_referer(\ViraCode\vira_code_nonce_action(), "nonce");

        // Check user capability.
        if (!\ViraCode\vira_code_user_can_manage()) {
            wp_send_json_error([
                "message" => __("Permission denied.", "vira-code"),
            ]);
        }

        $result = \ViraCode\vira_code_clear_logs();

        if ($result) {
            wp_send_json_success([
                "message" => __("Logs cleared successfully!", "vira-code"),
            ]);
        } else {
            wp_send_json_error([
                "message" => __("Failed to clear logs.", "vira-code"),
            ]);
        }
    }

    /**
     * Save settings.
     *
     * @return void
     */
    protected function saveSettings()
    {
        // Verify nonce.
        if (
            !isset($_POST["vira_code_settings_nonce"]) ||
            !wp_verify_nonce(
                sanitize_text_field(
                    wp_unslash($_POST["vira_code_settings_nonce"]),
                ),
                "vira_code_save_settings",
            )
        ) {
            add_settings_error(
                "vira_code_settings",
                "invalid_nonce",
                __("Security check failed.", "vira-code"),
            );
            return;
        }

        // Check user capability.
        if (!\ViraCode\vira_code_user_can_manage()) {
            add_settings_error(
                "vira_code_settings",
                "permission_denied",
                __("Permission denied.", "vira-code"),
            );
            return;
        }

        // Save safe mode setting.
        $safe_mode = isset($_POST["safe_mode"]) ? 1 : 0;
        update_option("vira_code_safe_mode", $safe_mode);

        add_settings_error(
            "vira_code_settings",
            "settings_saved",
            __("Settings saved successfully!", "vira-code"),
            "success",
        );
    }
}
