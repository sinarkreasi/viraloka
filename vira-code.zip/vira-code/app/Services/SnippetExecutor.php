<?php
/**
 * Snippet Executor Service
 *
 * @package ViraCode
 */

namespace ViraCode\Services;

use ViraCode\Models\SnippetModel;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * SnippetExecutor Class
 *
 * Validates and executes code snippets safely.
 */
class SnippetExecutor {

	/**
	 * Snippet model instance.
	 *
	 * @var SnippetModel
	 */
	protected $model;

	/**
	 * Executed snippets cache.
	 *
	 * @var array
	 */
	protected $executed = array();

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->model = new SnippetModel();
	}

	/**
	 * Execute snippets by scope and type.
	 *
	 * @param string $scope Snippet scope.
	 * @param string $type  Snippet type.
	 * @return void
	 */
	public function executeByScope( $scope, $type = '' ) {
		// Check if safe mode is enabled.
		if ( \ViraCode\vira_code_is_safe_mode() ) {
			return;
		}

		$snippets = $this->model->getByScope( $scope, $type );

		foreach ( $snippets as $snippet ) {
			$this->execute( $snippet );
		}
	}

	/**
	 * Execute a specific snippet by ID.
	 *
	 * @param int $snippet_id Snippet ID.
	 * @return array|false Execution result.
	 */
	public function executeById( $snippet_id ) {
		$snippet = $this->model->getById( $snippet_id );

		if ( ! $snippet ) {
			return false;
		}

		return $this->execute( $snippet );
	}

	/**
	 * Execute a snippet.
	 *
	 * @param array $snippet Snippet data.
	 * @return array Execution result.
	 */
	public function execute( $snippet ) {
		// Check if already executed in this request.
		$cache_key = $snippet['id'] . '_' . $snippet['type'];
		if ( isset( $this->executed[ $cache_key ] ) ) {
			return $this->executed[ $cache_key ];
		}

		// Apply pre-execution filter.
		$snippet = apply_filters( 'vira_code/snippet_before_execute', $snippet );

		$result = array(
			'success' => false,
			'output'  => '',
			'error'   => '',
		);

		try {
			// Execute based on snippet type.
			switch ( $snippet['type'] ) {
				case 'php':
					$result = $this->executePhp( $snippet );
					break;

				case 'js':
					$result = $this->executeJs( $snippet );
					break;

				case 'css':
					$result = $this->executeCss( $snippet );
					break;

				case 'html':
					$result = $this->executeHtml( $snippet );
					break;

				default:
					$result['error'] = sprintf(
						/* translators: %s: snippet type */
						__( 'Unknown snippet type: %s', 'vira-code' ),
						$snippet['type']
					);
					break;
			}

			// Log successful execution.
			if ( $result['success'] ) {
				\ViraCode\vira_code_log_execution( $snippet['id'], 'success' );

				// Clear any previous errors.
				if ( 'error' === $snippet['status'] ) {
					$this->model->clearError( $snippet['id'] );
					$this->model->updateStatus( $snippet['id'], 'active' );
				}
			} else {
				// Log error execution.
				\ViraCode\vira_code_log_execution( $snippet['id'], 'error', $result['error'] );
				$this->model->logError( $snippet['id'], $result['error'] );
			}
		} catch ( \Exception $e ) {
			$result['success'] = false;
			$result['error']   = $e->getMessage();

			// Log exception.
			\ViraCode\vira_code_log_execution( $snippet['id'], 'error', $e->getMessage() );
			$this->model->logError( $snippet['id'], $e->getMessage() );
		} catch ( \Error $e ) {
			$result['success'] = false;
			$result['error']   = $e->getMessage();

			// Log fatal error.
			\ViraCode\vira_code_log_execution( $snippet['id'], 'error', $e->getMessage() );
			$this->model->logError( $snippet['id'], $e->getMessage() );
		}

		// Fire post-execution action.
		do_action( 'vira_code/snippet_executed', $snippet, $result );

		// Cache the result.
		$this->executed[ $cache_key ] = $result;

		return $result;
	}

	/**
	 * Execute PHP snippet.
	 *
	 * @param array $snippet Snippet data.
	 * @return array
	 */
	protected function executePhp( $snippet ) {
		$result = array(
			'success' => false,
			'output'  => '',
			'error'   => '',
		);

		// Validate PHP code.
		$validation = $this->validatePhp( $snippet['code'] );
		if ( ! $validation['valid'] ) {
			$result['error'] = $validation['error'];
			return $result;
		}

		// Start output buffering.
		ob_start();

		try {
			// Set error handler.
			set_error_handler( function( $errno, $errstr, $errfile, $errline ) {
				throw new \ErrorException( $errstr, 0, $errno, $errfile, $errline );
			} );

			// Prepare code for execution.
			$code = $snippet['code'];

			// Remove PHP opening tags if present.
			$code = preg_replace( '/^<\?php\s+/i', '', $code );
			$code = preg_replace( '/^<\?\s+/i', '', $code );
			$code = preg_replace( '/\?>\s*$/', '', $code );

			// Execute the code in isolated scope.
			$this->executePhpCode( $code );

			// Restore error handler.
			restore_error_handler();

			$result['success'] = true;
			$result['output']  = ob_get_clean();

		} catch ( \ParseError $e ) {
			restore_error_handler();
			ob_end_clean();
			$result['error'] = sprintf(
				/* translators: 1: error message, 2: line number */
				__( 'Parse Error: %1$s on line %2$d', 'vira-code' ),
				$e->getMessage(),
				$e->getLine()
			);
		} catch ( \ErrorException $e ) {
			restore_error_handler();
			ob_end_clean();
			$result['error'] = sprintf(
				/* translators: 1: error message, 2: line number */
				__( 'Error: %1$s on line %2$d', 'vira-code' ),
				$e->getMessage(),
				$e->getLine()
			);
		} catch ( \Throwable $e ) {
			restore_error_handler();
			ob_end_clean();
			$result['error'] = sprintf(
				/* translators: 1: error type, 2: error message */
				__( '%1$s: %2$s', 'vira-code' ),
				get_class( $e ),
				$e->getMessage()
			);
		}

		return apply_filters( 'vira_code/php_executed', $result, $snippet );
	}

	/**
	 * Execute PHP code in isolated scope.
	 *
	 * @param string $code PHP code to execute.
	 * @return void
	 */
	protected function executePhpCode( $code ) {
		eval( $code ); // phpcs:ignore Squiz.PHP.Eval.Discouraged
	}

	/**
	 * Validate PHP code.
	 *
	 * @param string $code PHP code.
	 * @return array
	 */
	protected function validatePhp( $code ) {
		$result = array(
			'valid' => true,
			'error' => '',
		);

		// Check for dangerous functions (optional - can be disabled via filter).
		$dangerous_functions = apply_filters(
			'vira_code/php_dangerous_functions',
			array(
				// File system functions that could be dangerous.
				// Uncomment to restrict:
				// 'unlink',
				// 'rmdir',
				// 'file_put_contents',
			)
		);

		foreach ( $dangerous_functions as $function ) {
			if ( preg_match( '/\b' . preg_quote( $function, '/' ) . '\s*\(/i', $code ) ) {
				$result['valid'] = false;
				$result['error'] = sprintf(
					/* translators: %s: function name */
					__( 'Dangerous function not allowed: %s', 'vira-code' ),
					$function
				);
				return $result;
			}
		}

		// Basic syntax check using php -l if a CLI is available.
		// Prefer PHP_BINARY if defined, otherwise try 'php'. If exec isn't available we skip this check.
		if ( function_exists( 'exec' ) ) {
			$php_cmd = defined( 'PHP_BINARY' ) ? PHP_BINARY : 'php';
			// Ensure we have a usable PHP CLI by attempting to run php -v quietly.
			$can_run_php = false;
			@exec( escapeshellarg( $php_cmd ) . ' -v 2>&1', $dummy, $php_ret );
			if ( 0 === $php_ret ) {
				$can_run_php = true;
			}

			if ( $can_run_php ) {
				$temp_file = tempnam( sys_get_temp_dir(), 'vira_code_' );
				if ( $temp_file ) {
					// Prepare code with PHP tags.
					$code_to_check = "<?php\n" . $code;
					file_put_contents( $temp_file, $code_to_check );

					$output = array();
					$return_var = 0;
					@exec( escapeshellarg( $php_cmd ) . " -l " . escapeshellarg( $temp_file ) . " 2>&1", $output, $return_var );

					@unlink( $temp_file );

					if ( 0 !== $return_var ) {
						$result['valid'] = false;
						$result['error'] = implode( "\n", $output );
					}
				}
			} else {
				// Can't run php CLI here (common on some Windows setups). Skip strict syntax check.
				// Rely on runtime validation during test/execute.
				if ( function_exists('error_log') ) {
					error_log('Vira Code: PHP CLI not available, skipping syntax check');
				}
			}
		}

		return apply_filters( 'vira_code/php_validated', $result, $code );
	}

	/**
	 * Execute JavaScript snippet.
	 *
	 * @param array $snippet Snippet data.
	 * @return array
	 */
	protected function executeJs( $snippet ) {
		$result = array(
			'success' => true,
			'output'  => '',
			'error'   => '',
		);

		// Sanitize the JavaScript code.
		$code = apply_filters( 'vira_code/js_code', $snippet['code'], $snippet );

		// Output inline script.
		echo "\n<script type=\"text/javascript\">\n";
		echo "/* Vira Code Snippet: " . esc_attr( $snippet['title'] ) . " */\n";
		echo $code; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo "\n</script>\n";

		$result['output'] = 'JavaScript snippet enqueued.';

		return apply_filters( 'vira_code/js_executed', $result, $snippet );
	}

	/**
	 * Execute CSS snippet.
	 *
	 * @param array $snippet Snippet data.
	 * @return array
	 */
	protected function executeCss( $snippet ) {
		$result = array(
			'success' => true,
			'output'  => '',
			'error'   => '',
		);

		// Sanitize the CSS code.
		$code = apply_filters( 'vira_code/css_code', $snippet['code'], $snippet );

		// Output inline style.
		echo "\n<style type=\"text/css\">\n";
		echo "/* Vira Code Snippet: " . esc_attr( $snippet['title'] ) . " */\n";
		echo $code; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo "\n</style>\n";

		$result['output'] = 'CSS snippet enqueued.';

		return apply_filters( 'vira_code/css_executed', $result, $snippet );
	}

	/**
	 * Execute HTML snippet.
	 *
	 * @param array $snippet Snippet data.
	 * @return array
	 */
	protected function executeHtml( $snippet ) {
		$result = array(
			'success' => true,
			'output'  => '',
			'error'   => '',
		);

		// Sanitize the HTML code based on context.
		$code = apply_filters( 'vira_code/html_code', $snippet['code'], $snippet );

		// Output HTML.
		echo "\n<!-- Vira Code Snippet: " . esc_attr( $snippet['title'] ) . " -->\n";
		echo $code; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo "\n<!-- End Vira Code Snippet -->\n";

		$result['output'] = 'HTML snippet outputted.';

		return apply_filters( 'vira_code/html_executed', $result, $snippet );
	}

	/**
	 * Test snippet execution without actually running it.
	 *
	 * @param array $snippet Snippet data.
	 * @return array
	 */
	public function test( $snippet ) {
		$result = array(
			'valid'   => true,
			'message' => __( 'Snippet validation passed.', 'vira-code' ),
			'errors'  => array(),
		);

		// Only validate PHP snippets.
		if ( 'php' === $snippet['type'] ) {
			$validation = $this->validatePhp( $snippet['code'] );
			if ( ! $validation['valid'] ) {
				$result['valid']    = false;
				$result['message']  = __( 'Snippet validation failed.', 'vira-code' );
				$result['errors'][] = $validation['error'];
			}
		}

		return apply_filters( 'vira_code/snippet_tested', $result, $snippet );
	}

	/**
	 * Get executed snippets cache.
	 *
	 * @return array
	 */
	public function getExecuted() {
		return $this->executed;
	}

	/**
	 * Clear executed snippets cache.
	 *
	 * @return void
	 */
	public function clearCache() {
		$this->executed = array();
	}
}
