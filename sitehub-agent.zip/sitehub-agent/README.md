# SiteHub Agent

Lightweight WordPress plugin that connects a remote site to a Viraloka SiteHub hub.

## Installation

1. Copy the `sitehub-agent` folder into `wp-content/plugins/` on the **remote** WordPress site
2. Activate the plugin in **Plugins → Installed Plugins**
3. Go to **Settings → SiteHub Agent**
4. Fill in:
   - **Hub Callback URL** — copy from your Viraloka admin → SiteHub → Settings tab
   - **API Key** — copy from the banner shown after connecting the site in SiteHub → Connected Sites
5. Check **Enable Agent** and click **Save Settings**
6. Click **Send Test Ping** to verify the connection

## How it works

```
Remote Site (Agent)                    Viraloka Hub
      │                                      │
      │── POST /portal/sitehub/agent/callback ──▶│  health data + command results
      │◀── { commands: [...] } ───────────────────│  pending commands
      │                                      │
      │  (executes commands locally)         │
      │── POST /portal/sitehub/agent/callback ──▶│  command results
```

Every 5 minutes the agent:
1. Collects health data (WP version, PHP version, pending updates, security alerts)
2. POSTs it to the hub with the API key as a Bearer token
3. Receives any pending commands from the hub
4. Executes each command and reports the result back

## Supported Commands

| Command            | Description                              |
|--------------------|------------------------------------------|
| `fetch_health`     | Return current health data               |
| `update_core`      | Update WordPress core                    |
| `update_plugins`   | Update all plugins (or one by slug)      |
| `update_themes`    | Update all themes (or one by slug)       |
| `trigger_backup`   | Trigger UpdraftPlus / BackWPup backup    |
| `activate_plugin`  | Activate a plugin by slug                |
| `deactivate_plugin`| Deactivate a plugin by slug              |

## REST API (on-demand commands)

The agent also exposes a REST API for immediate command execution:

```
POST /wp-json/sitehub/v1/command
GET  /wp-json/sitehub/v1/health
GET  /wp-json/sitehub/v1/ping      (public — no auth needed)
```

All authenticated endpoints require `Authorization: Bearer <api_key>`.
