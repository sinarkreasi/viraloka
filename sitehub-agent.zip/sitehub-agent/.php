<?php
/**
 * Plugin Name: SiteHub Agent
 * Plugin URI:  https://viraloka.com/
 * Description: Lightweight, capability-based remote agent connecting this site to Viraloka SiteHub.
 * Version:     2.0.0
 * Author:      Viraloka
 * License:     GPL-2.0+
 */

defined('ABSPATH') || exit;

define('SITEHUB_AGENT_VERSION',  '2.0.0');
define('SITEHUB_AGENT_DIR',      plugin_dir_path(__FILE__));
define('SITEHUB_AGENT_FILE',     __FILE__);

// ── Autoload includes ──────────────────────────────────────────────────────
foreach ([
    'class-sitehub-logger.php',
    'class-sitehub-auth.php',
    'class-sitehub-health.php',
    'class-sitehub-capability-registry.php',
    'class-sitehub-executor.php',
    'class-sitehub-commands.php',
    'class-sitehub-scheduler.php',
    'class-sitehub-heartbeat.php',
    'class-sitehub-rest-api.php',
    'class-sitehub-settings.php',
] as $file) {
    require_once SITEHUB_AGENT_DIR . 'includes/' . $file;
}

// ── Boot ───────────────────────────────────────────────────────────────────
add_action('plugins_loaded', function () {
    SiteHub_Capability_Registry::init();
    SiteHub_REST_API::init();
    SiteHub_Heartbeat::init();
    SiteHub_Scheduler::init();
    SiteHub_Settings::init();
});

// ── Activation / deactivation ──────────────────────────────────────────────
register_activation_hook(__FILE__, function () {
    SiteHub_Scheduler::schedule();
});

register_deactivation_hook(__FILE__, function () {
    SiteHub_Scheduler::unschedule();
});
