<?php
/**
 * Plugin Name: SiteHub Agent
 * Plugin URI:  https://viraloka.com/product-category/addons/sitehub-agent
 * Description: Connects this WordPress site to a Viraloka SiteHub hub for remote management, health monitoring, and update control.
 * Version:     2.1.1
 * Author:      Viraloka
 * License:     GPL-2.0+
 * Text Domain: sitehub-agent
 */

defined('ABSPATH') || exit;

define('SITEHUB_AGENT_VERSION', '2.1.1');
define('SITEHUB_AGENT_FILE',    __FILE__);
define('SITEHUB_AGENT_DIR',     plugin_dir_path(__FILE__));

// Core layer
require_once SITEHUB_AGENT_DIR . 'includes/class-sitehub-logger.php';
require_once SITEHUB_AGENT_DIR . 'includes/class-sitehub-auth.php';

// Capability layer
require_once SITEHUB_AGENT_DIR . 'includes/class-sitehub-capability-registry.php';

// Data collection layer (v2.1 — capability-based collectors)
require_once SITEHUB_AGENT_DIR . 'includes/class-sitehub-collector.php';

// Execution layer
require_once SITEHUB_AGENT_DIR . 'includes/class-sitehub-health.php';
require_once SITEHUB_AGENT_DIR . 'includes/class-sitehub-commands.php';
require_once SITEHUB_AGENT_DIR . 'includes/class-sitehub-executor.php';

// Communication & scheduling
require_once SITEHUB_AGENT_DIR . 'includes/class-sitehub-heartbeat.php';
require_once SITEHUB_AGENT_DIR . 'includes/class-sitehub-scheduler.php';
require_once SITEHUB_AGENT_DIR . 'includes/class-sitehub-rest-api.php';

// Admin
require_once SITEHUB_AGENT_DIR . 'includes/class-sitehub-settings.php';

function sitehub_agent_init(): void
{
    SiteHub_Settings::init();
    SiteHub_REST_API::init();
    SiteHub_Scheduler::init();
}
add_action('plugins_loaded', 'sitehub_agent_init');

// Register custom cron interval (5 minutes)
add_filter('cron_schedules', function (array $schedules): array {
    $schedules['sitehub_five_minutes'] = [
        'interval' => 300,
        'display'  => 'Every 5 Minutes (SiteHub)',
    ];
    return $schedules;
});

register_activation_hook(__FILE__, function () {
    SiteHub_Scheduler::schedule();
});

register_deactivation_hook(__FILE__, function () {
    SiteHub_Scheduler::unschedule();
});
