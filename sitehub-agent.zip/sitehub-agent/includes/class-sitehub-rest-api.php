<?php
defined('ABSPATH') || exit;

/**
 * REST API endpoints for SiteHub Agent v2.1.
 *
 * POST /wp-json/sitehub-agent/v2/collect       — collect requested capabilities (v2.1)
 * POST /wp-json/sitehub-agent/v2/execute       — execute a management capability
 * GET  /wp-json/sitehub-agent/v2/status        — agent status + health
 * GET  /wp-json/sitehub-agent/v2/capabilities  — list capabilities
 * GET  /wp-json/sitehub-agent/v2/ping          — public liveness check
 */
class SiteHub_REST_API
{
    const NS = 'sitehub-agent/v2';

    public static function init(): void
    {
        add_action('rest_api_init', [self::class, 'registerRoutes']);
    }

    public static function registerRoutes(): void
    {
        // v2.1 — capability-based data collection
        register_rest_route(self::NS, '/collect', [
            'methods'             => 'POST',
            'callback'            => [self::class, 'handleCollect'],
            'permission_callback' => [self::class, 'authenticate'],
        ]);

        register_rest_route(self::NS, '/execute', [
            'methods'             => 'POST',
            'callback'            => [self::class, 'handleExecute'],
            'permission_callback' => [self::class, 'authenticate'],
        ]);

        register_rest_route(self::NS, '/status', [
            'methods'             => 'GET',
            'callback'            => [self::class, 'handleStatus'],
            'permission_callback' => [self::class, 'authenticate'],
        ]);

        register_rest_route(self::NS, '/capabilities', [
            'methods'             => 'GET',
            'callback'            => [self::class, 'handleCapabilities'],
            'permission_callback' => [self::class, 'authenticate'],
        ]);

        register_rest_route(self::NS, '/ping', [
            'methods'             => 'GET',
            'callback'            => [self::class, 'handlePing'],
            'permission_callback' => '__return_true',
        ]);
    }

    // -------------------------------------------------------------------------
    // Auth

    public static function authenticate(\WP_REST_Request $request): bool|\WP_Error
    {
        if (!SiteHub_Settings::isConfigured()) {
            return new \WP_Error('sitehub_disabled', 'SiteHub Agent is not configured.', ['status' => 503]);
        }

        // Extract auth from headers
        $auth = [
            'agent_id'  => $request->get_header('x-sitehub-agent-id') ?? '',
            'signature' => $request->get_header('x-sitehub-sig')      ?? '',
            'timestamp' => $request->get_header('x-sitehub-ts')       ?? '',
            'nonce'     => $request->get_header('x-sitehub-nonce')    ?? '',
        ];

        // Fallback: legacy Bearer token for backward compat
        if (empty($auth['signature'])) {
            $header = $request->get_header('authorization') ?? '';
            $apiKey = '';
            if (str_starts_with($header, 'Bearer ')) {
                $apiKey = trim(substr($header, 7));
            }
            if (!empty($apiKey) && $apiKey === SiteHub_Settings::getApiKey()) {
                return true;
            }
            return new \WP_Error('sitehub_unauthorized', 'Missing authentication headers.', ['status' => 401]);
        }

        $body   = (array) ($request->get_json_params() ?? []);
        $result = SiteHub_Auth::validateRequest($auth, $body);

        if (is_wp_error($result)) {
            return $result;
        }

        return true;
    }

    // -------------------------------------------------------------------------
    // Handlers

    /**
     * POST /collect
     *
     * Body: { "requested_capabilities": ["collect_meta_data", "collect_http_headers"] }
     *
     * Validates each requested capability, runs only those collectors,
     * and returns a single normalized response. Unknown or non-collect
     * capabilities are reported in the `skipped` array.
     */
    public static function handleCollect(\WP_REST_Request $request): \WP_REST_Response
    {
        $start  = microtime(true);
        $body   = (array) ($request->get_json_params() ?? []);
        $requested = array_map('sanitize_text_field', (array) ($body['requested_capabilities'] ?? []));
        $params    = (array) ($body['params'] ?? []);

        if (empty($requested)) {
            return new \WP_REST_Response(
                SiteHub_Executor::error('requested_capabilities is required', 400),
                400
            );
        }

        $data    = [];
        $skipped = [];

        foreach ($requested as $capability) {
            if (!SiteHub_Capability_Registry::isCollectCapability($capability)) {
                $skipped[] = $capability;
                continue;
            }

            // Map capability → collector method
            $method = $capability; // e.g. "collect_meta_data"
            if (!method_exists('SiteHub_Collector', $method)) {
                $skipped[] = $capability;
                continue;
            }

            try {
                // Strip "collect_" prefix for the response key
                $key        = substr($capability, strlen('collect_'));
                $data[$key] = SiteHub_Collector::$method($params[$capability] ?? []);
            } catch (\Throwable $e) {
                $skipped[] = $capability;
                SiteHub_Logger::log($capability, 'failed', ['detail' => $e->getMessage()]);
            }
        }

        $elapsed = round((microtime(true) - $start) * 1000, 2) . 'ms';
        SiteHub_Logger::log('collect', 'completed', ['execution_time' => $elapsed]);

        return new \WP_REST_Response([
            'status'         => 'success',
            'data'           => $data,
            'skipped'        => $skipped,
            'execution_time' => $elapsed,
        ], 200);
    }

    public static function handleExecute(\WP_REST_Request $request): \WP_REST_Response
    {
        $body   = (array) ($request->get_json_params() ?? []);
        $action = sanitize_text_field($body['action'] ?? '');
        $params = (array) ($body['params'] ?? []);

        if (empty($action)) {
            return new \WP_REST_Response(
                SiteHub_Executor::error('action is required', 400),
                400
            );
        }

        $result     = SiteHub_Executor::run($action, $params);
        $httpStatus = $result['status'] === 'success' ? 200 : ($result['code'] ?? 422);

        return new \WP_REST_Response($result, $httpStatus);
    }

    public static function handleStatus(\WP_REST_Request $request): \WP_REST_Response
    {
        $next = wp_next_scheduled('sitehub_heartbeat_cron');

        return new \WP_REST_Response(SiteHub_Executor::success([
            'agent_id'       => SiteHub_Auth::getAgentId(),
            'agent_version'  => SITEHUB_AGENT_VERSION,
            'site_url'       => home_url(),
            'wp_version'     => get_bloginfo('version'),
            'php_version'    => PHP_VERSION,
            'enabled'        => SiteHub_Settings::isEnabled(),
            'configured'     => SiteHub_Settings::isConfigured(),
            'next_heartbeat' => $next ? human_time_diff($next) . ' from now' : 'not scheduled',
            'health'         => SiteHub_Health::collect(),
        ]), 200);
    }

    public static function handleCapabilities(\WP_REST_Request $request): \WP_REST_Response
    {
        return new \WP_REST_Response(
            SiteHub_Executor::success(SiteHub_Capability_Registry::report()),
            200
        );
    }

    public static function handlePing(\WP_REST_Request $request): \WP_REST_Response
    {
        return new \WP_REST_Response([
            'status'        => 'success',
            'agent'         => 'SiteHub Agent',
            'version'       => SITEHUB_AGENT_VERSION,
            'site_url'      => home_url(),
            'api_version'   => 'v2',
        ], 200);
    }
}
