<?php
defined('ABSPATH') || exit;

/**
 * Settings page for SiteHub Agent v2.
 * Shows: connection config, v2 status, capabilities list, recent log entries.
 */
class SiteHub_Settings
{
    const OPTION_HUB_URL = 'sitehub_hub_url';
    const OPTION_API_KEY = 'sitehub_api_key';
    const OPTION_ENABLED = 'sitehub_enabled';

    public static function init(): void
    {
        add_action('admin_menu',    [self::class, 'addMenuPage']);
        add_action('admin_init',    [self::class, 'registerSettings']);
        add_action('admin_notices', [self::class, 'maybeShowNotConfiguredNotice']);
    }

    public static function addMenuPage(): void
    {
        add_options_page(
            'SiteHub Agent',
            'SiteHub Agent',
            'manage_options',
            'sitehub-agent',
            [self::class, 'renderPage']
        );
    }

    public static function registerSettings(): void
    {
        register_setting('sitehub_agent', self::OPTION_HUB_URL, ['sanitize_callback' => 'esc_url_raw']);
        register_setting('sitehub_agent', self::OPTION_API_KEY, ['sanitize_callback' => 'sanitize_text_field']);
        register_setting('sitehub_agent', self::OPTION_ENABLED, ['sanitize_callback' => 'absint']);
    }

    public static function getHubUrl(): string  { return (string) get_option(self::OPTION_HUB_URL, ''); }
    public static function getApiKey(): string  { return (string) get_option(self::OPTION_API_KEY, ''); }
    public static function isEnabled(): bool    { return (bool) get_option(self::OPTION_ENABLED, 0); }
    public static function isConfigured(): bool { return self::isEnabled() && !empty(self::getHubUrl()) && !empty(self::getApiKey()); }

    public static function maybeShowNotConfiguredNotice(): void
    {
        $screen = get_current_screen();
        if (!$screen || $screen->id === 'settings_page_sitehub-agent') {
            return;
        }
        if (!self::isConfigured() && current_user_can('manage_options')) {
            echo '<div class="notice notice-warning"><p>'
                . '<strong>SiteHub Agent</strong> is not configured. '
                . '<a href="' . esc_url(admin_url('options-general.php?page=sitehub-agent')) . '">Configure now →</a>'
                . '</p></div>';
        }
    }

    public static function renderPage(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }

        $pingResult = null;
        if (isset($_POST['sitehub_test_ping']) && check_admin_referer('sitehub_test_ping')) {
            $pingResult = SiteHub_Heartbeat::sendHeartbeat(true);
        }

        $tab = sanitize_text_field($_GET['tab'] ?? 'settings');
        $tabs = ['settings' => 'Settings', 'status' => 'Status', 'capabilities' => 'Capabilities', 'logs' => 'Logs'];
        ?>
        <div class="wrap">
            <h1>
                <span class="dashicons dashicons-admin-multisite" style="font-size:28px;vertical-align:middle;margin-right:6px;"></span>
                SiteHub Agent <span style="font-size:13px;color:#888;font-weight:normal;">v<?php echo SITEHUB_AGENT_VERSION; ?></span>
            </h1>

            <?php if ($pingResult !== null): ?>
                <div class="notice notice-<?php echo $pingResult['success'] ? 'success' : 'error'; ?> is-dismissible">
                    <p><?php echo $pingResult['success']
                        ? '✓ Connected to hub. ' . count($pingResult['commands'] ?? []) . ' pending command(s).'
                        : '✗ Connection failed: ' . esc_html($pingResult['error'] ?? 'Unknown error'); ?></p>
                </div>
            <?php endif; ?>

            <nav class="nav-tab-wrapper" style="margin-bottom:20px;">
                <?php foreach ($tabs as $key => $label): ?>
                    <a href="?page=sitehub-agent&tab=<?php echo $key; ?>"
                       class="nav-tab <?php echo $tab === $key ? 'nav-tab-active' : ''; ?>">
                        <?php echo esc_html($label); ?>
                    </a>
                <?php endforeach; ?>
            </nav>

            <?php if ($tab === 'settings'): ?>
                <?php self::renderSettingsTab(); ?>
            <?php elseif ($tab === 'status'): ?>
                <?php self::renderStatusTab(); ?>
            <?php elseif ($tab === 'capabilities'): ?>
                <?php self::renderCapabilitiesTab(); ?>
            <?php elseif ($tab === 'logs'): ?>
                <?php self::renderLogsTab(); ?>
            <?php endif; ?>
        </div>
        <?php
    }

    private static function renderSettingsTab(): void
    {
        ?>
        <form method="post" action="options.php">
            <?php settings_fields('sitehub_agent'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="sitehub_enabled">Enable Agent</label></th>
                    <td>
                        <label>
                            <input type="checkbox" id="sitehub_enabled" name="<?php echo self::OPTION_ENABLED; ?>" value="1"
                                <?php checked(1, self::isEnabled()); ?>>
                            Allow this site to communicate with the SiteHub hub
                        </label>
                    </td>
                </tr>
                <tr>
                    <th><label for="sitehub_hub_url">Hub Callback URL <span style="color:#d63638;">*</span></label></th>
                    <td>
                        <input type="url" id="sitehub_hub_url" name="<?php echo self::OPTION_HUB_URL; ?>"
                            value="<?php echo esc_attr(self::getHubUrl()); ?>"
                            class="regular-text" placeholder="https://yourhub.com/portal/sitehub/agent/callback">
                        <p class="description">Copy from SiteHub Settings in your Viraloka admin.</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="sitehub_api_key">API Key <span style="color:#d63638;">*</span></label></th>
                    <td>
                        <input type="text" id="sitehub_api_key" name="<?php echo self::OPTION_API_KEY; ?>"
                            value="<?php echo esc_attr(self::getApiKey()); ?>"
                            class="regular-text" placeholder="Paste the API key from SiteHub">
                        <p class="description">Generated when you added this site in the SiteHub Connected Sites tab.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button('Save Settings'); ?>
        </form>

        <?php if (self::isConfigured()): ?>
            <hr>
            <h2>Connection Test</h2>
            <form method="post">
                <?php wp_nonce_field('sitehub_test_ping'); ?>
                <input type="hidden" name="sitehub_test_ping" value="1">
                <?php submit_button('Send Test Ping', 'secondary'); ?>
            </form>
        <?php endif; ?>
        <?php
    }

    private static function renderStatusTab(): void
    {
        $next = wp_next_scheduled('sitehub_heartbeat_cron');
        ?>
        <table class="form-table">
            <tr><th>Agent Version</th><td><?php echo esc_html(SITEHUB_AGENT_VERSION); ?></td></tr>
            <tr><th>Agent ID</th><td><code><?php echo esc_html(SiteHub_Auth::getAgentId()); ?></code></td></tr>
            <tr><th>Public Key</th><td>
                <?php $pk = SiteHub_Auth::getPublicKey(); ?>
                <?php echo $pk ? '<code>' . esc_html($pk) . '</code>' : '<em>Not set</em>'; ?>
            </td></tr>
            <tr><th>Site URL</th><td><?php echo esc_html(home_url()); ?></td></tr>
            <tr><th>WordPress</th><td><?php echo esc_html(get_bloginfo('version')); ?></td></tr>
            <tr><th>PHP</th><td><?php echo esc_html(PHP_VERSION); ?></td></tr>
            <tr><th>Agent Enabled</th><td><?php echo self::isEnabled()
                ? '<span style="color:#00a32a;">Yes</span>'
                : '<span style="color:#d63638;">No</span>'; ?></td></tr>
            <tr><th>Hub Configured</th><td><?php echo self::isConfigured()
                ? '<span style="color:#00a32a;">Yes</span>'
                : '<span style="color:#d63638;">No — fill in Hub URL and API Key</span>'; ?></td></tr>
            <tr><th>Next Heartbeat</th><td><?php echo $next
                ? esc_html(human_time_diff($next) . ' from now')
                : 'Not scheduled'; ?></td></tr>
            <tr><th>REST Endpoint</th><td><code><?php echo esc_html(home_url('/wp-json/sitehub-agent/v2/ping')); ?></code></td></tr>
            <tr><th>Collect Endpoint</th><td><code><?php echo esc_html(home_url('/wp-json/sitehub-agent/v2/collect')); ?></code></td></tr>
            <tr><th>Execute Endpoint</th><td><code><?php echo esc_html(home_url('/wp-json/sitehub-agent/v2/execute')); ?></code></td></tr>
        </table>
        <?php
    }

    private static function renderCapabilitiesTab(): void
    {
        $report = SiteHub_Capability_Registry::report();
        $collect = SiteHub_Capability_Registry::getCollectCapabilities();
        $all     = SiteHub_Capability_Registry::getAll();
        $manage  = array_values(array_diff($all, $collect));
        ?>
        <p>This agent exposes <strong><?php echo count($all); ?></strong> capabilities to SiteHub (v<?php echo esc_html($report['capability_version']); ?>).</p>

        <h3>Data Collection Capabilities (<?php echo count($collect); ?>)</h3>
        <p class="description">Served via <code>POST /wp-json/sitehub-agent/v2/collect</code></p>
        <table class="widefat striped" style="max-width:600px;margin-bottom:20px;">
            <thead><tr><th>#</th><th>Capability</th></tr></thead>
            <tbody>
                <?php foreach ($collect as $i => $cap): ?>
                    <tr><td><?php echo $i + 1; ?></td><td><code><?php echo esc_html($cap); ?></code></td></tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <h3>Management Capabilities (<?php echo count($manage); ?>)</h3>
        <p class="description">Served via <code>POST /wp-json/sitehub-agent/v2/execute</code></p>
        <table class="widefat striped" style="max-width:600px;">
            <thead><tr><th>#</th><th>Capability</th></tr></thead>
            <tbody>
                <?php foreach ($manage as $i => $cap): ?>
                    <tr><td><?php echo $i + 1; ?></td><td><code><?php echo esc_html($cap); ?></code></td></tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php
    }

    private static function renderLogsTab(): void
    {
        $logs = SiteHub_Logger::get(50);
        ?>
        <p>Last 50 log entries (newest first).</p>
        <?php if (empty($logs)): ?>
            <p><em>No log entries yet.</em></p>
        <?php else: ?>
            <table class="widefat striped">
                <thead>
                    <tr>
                        <th>Timestamp</th>
                        <th>Action</th>
                        <th>Status</th>
                        <th>Time</th>
                        <th>Detail</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $entry): ?>
                        <tr>
                            <td><?php echo esc_html($entry['timestamp']); ?></td>
                            <td><code><?php echo esc_html($entry['action']); ?></code></td>
                            <td>
                                <?php
                                $color = match ($entry['status']) {
                                    'completed' => '#00a32a',
                                    'failed', 'rejected' => '#d63638',
                                    default => '#888',
                                };
                                ?>
                                <span style="color:<?php echo $color; ?>;"><?php echo esc_html($entry['status']); ?></span>
                            </td>
                            <td><?php echo esc_html($entry['execution_time'] ?? '—'); ?></td>
                            <td><?php echo esc_html($entry['detail'] ?? ''); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <form method="post" style="margin-top:10px;">
                <?php wp_nonce_field('sitehub_clear_log'); ?>
                <input type="hidden" name="sitehub_clear_log" value="1">
                <?php submit_button('Clear Logs', 'delete small', 'submit', false); ?>
            </form>
        <?php endif; ?>
        <?php
        // Handle clear
        if (isset($_POST['sitehub_clear_log']) && check_admin_referer('sitehub_clear_log')) {
            SiteHub_Logger::clear();
            echo '<div class="notice notice-success"><p>Logs cleared.</p></div>';
        }
    }
}
