<?php
defined('ABSPATH') || exit;

/**
 * Handles request authentication for SiteHub Agent v2.
 * Validates: signature, timestamp (±30s), nonce (anti-replay).
 */
class SiteHub_Auth
{
    const OPTION_AGENT_ID   = 'sitehub_agent_id';
    const OPTION_SECRET_KEY = 'sitehub_secret_key';
    const OPTION_PUBLIC_KEY = 'sitehub_public_key';
    const NONCE_OPTION      = 'sitehub_used_nonces';
    const NONCE_TTL         = 60; // seconds to keep nonces

    // -------------------------------------------------------------------------
    // Identity

    public static function getAgentId(): string
    {
        $id = get_option(self::OPTION_AGENT_ID, '');
        if (empty($id)) {
            $id = 'agent_' . wp_generate_uuid4();
            update_option(self::OPTION_AGENT_ID, $id, false);
        }
        return $id;
    }

    public static function getSecretKey(): string
    {
        $key = get_option(self::OPTION_SECRET_KEY, '');
        if (empty($key)) {
            $key = bin2hex(random_bytes(32));
            update_option(self::OPTION_SECRET_KEY, $key, false);
        }
        return $key;
    }

    public static function getPublicKey(): string
    {
        return (string) get_option(self::OPTION_PUBLIC_KEY, '');
    }

    // -------------------------------------------------------------------------
    // Outbound signing (agent → hub)

    public static function signRequest(array $payload): array
    {
        $timestamp = gmdate('c');
        $nonce     = bin2hex(random_bytes(16));
        $agentId   = self::getAgentId();

        // Use the shared api_key as the HMAC secret so the hub can verify
        $secret    = SiteHub_Settings::getApiKey() ?: self::getSecretKey();

        $signature = self::buildSignature($agentId, $timestamp, $nonce, $payload, $secret);

        return [
            'agent_id'  => $agentId,
            'signature' => $signature,
            'timestamp' => $timestamp,
            'nonce'     => $nonce,
        ];
    }

    // -------------------------------------------------------------------------
    // Inbound validation (hub → agent)

    /**
     * Validate an incoming request.
     *
     * @param array $auth  ['agent_id', 'signature', 'timestamp', 'nonce']
     * @param array $payload  The request body/params being signed
     * @return true|\WP_Error
     */
    public static function validateRequest(array $auth, array $payload = []): true|\WP_Error
    {
        $agentId   = $auth['agent_id']  ?? '';
        $signature = $auth['signature'] ?? '';
        $timestamp = $auth['timestamp'] ?? '';
        $nonce     = $auth['nonce']     ?? '';

        if (empty($agentId) || empty($signature) || empty($timestamp) || empty($nonce)) {
            return new \WP_Error('sitehub_auth_missing', 'Missing auth fields.', ['status' => 401]);
        }

        // Validate agent_id matches this agent
        if ($agentId !== self::getAgentId()) {
            return new \WP_Error('sitehub_auth_invalid', 'Invalid agent_id.', ['status' => 401]);
        }

        // Validate timestamp ±30 seconds
        $requestTime = strtotime($timestamp);
        if ($requestTime === false || abs(time() - $requestTime) > 30) {
            return new \WP_Error('sitehub_auth_expired', 'Request timestamp expired.', ['status' => 401]);
        }

        // Validate nonce (anti-replay)
        if (!self::consumeNonce($nonce)) {
            return new \WP_Error('sitehub_auth_replay', 'Nonce already used.', ['status' => 401]);
        }

        // Validate signature
        $expected = self::buildSignature($agentId, $timestamp, $nonce, $payload, self::getSecretKey());
        if (!hash_equals($expected, $signature)) {
            return new \WP_Error('sitehub_auth_signature', 'Invalid signature.', ['status' => 401]);
        }

        return true;
    }

    // -------------------------------------------------------------------------
    // Helpers

    private static function buildSignature(
        string $agentId,
        string $timestamp,
        string $nonce,
        array  $payload,
        string $secret
    ): string {
        $data = $agentId . '|' . $timestamp . '|' . $nonce . '|' . wp_json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        return hash_hmac('sha256', $data, $secret);
    }

    private static function consumeNonce(string $nonce): bool
    {
        $nonces = get_option(self::NONCE_OPTION, []);
        $now    = time();

        // Purge expired nonces
        $nonces = array_filter($nonces, fn($exp) => $exp > $now);

        if (isset($nonces[$nonce])) {
            return false; // already used
        }

        $nonces[$nonce] = $now + self::NONCE_TTL;
        update_option(self::NONCE_OPTION, $nonces, false);
        return true;
    }
}
