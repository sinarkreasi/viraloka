<?php
defined('ABSPATH') || exit;

/**
 * Sends periodic heartbeats to the hub (v2).
 * Signs outbound requests via SiteHub_Auth.
 * Sends capability list on connect.
 * Dispatches incoming commands through SiteHub_Executor.
 */
class SiteHub_Heartbeat
{
    public static function init(): void
    {
        add_action('sitehub_heartbeat_cron', [self::class, 'sendHeartbeat']);
    }

    /**
     * @param bool $force  Skip isConfigured check (manual test ping)
     */
    public static function sendHeartbeat(bool $force = false): array
    {
        if (!$force && !SiteHub_Settings::isConfigured()) {
            return ['success' => false, 'error' => 'Agent not configured.'];
        }

        $hubUrl = SiteHub_Settings::getHubUrl();
        $health = SiteHub_Health::collect();

        // Build full body first, then sign it
        $body = array_merge($health, [
            'capabilities' => SiteHub_Capability_Registry::report(),
        ]);

        // Include api_key in body so the hub can link agent_id on first contact
        $apiKey = SiteHub_Settings::getApiKey();
        if ($apiKey) {
            $body['api_key'] = $apiKey;
        }

        // Sign the full body so the hub can verify against raw JSON
        $authHeaders = SiteHub_Auth::signRequest($body);

        $response = wp_remote_post($hubUrl, [
            'timeout'     => 15,
            'redirection' => 3,
            'headers'     => [
                'Content-Type'       => 'application/json',
                'Accept'             => 'application/json',
                'X-SiteHub-Agent-Id' => $authHeaders['agent_id'],
                'X-SiteHub-Sig'      => $authHeaders['signature'],
                'X-SiteHub-Ts'       => $authHeaders['timestamp'],
                'X-SiteHub-Nonce'    => $authHeaders['nonce'],
            ],
            'body' => wp_json_encode($body),
        ]);

        if (is_wp_error($response)) {
            SiteHub_Logger::log('heartbeat', 'failed', ['detail' => $response->get_error_message()]);
            return ['success' => false, 'error' => $response->get_error_message()];
        }

        $code    = wp_remote_retrieve_response_code($response);
        $decoded = json_decode(wp_remote_retrieve_body($response), true);

        if ($code !== 200 || empty($decoded['success'])) {
            $err = $decoded['error'] ?? "Hub returned HTTP {$code}";
            SiteHub_Logger::log('heartbeat', 'failed', ['detail' => $err]);
            return ['success' => false, 'error' => $err];
        }

        SiteHub_Logger::log('heartbeat', 'completed');

        // Execute any pending commands the hub sent back
        foreach ((array) ($decoded['commands'] ?? []) as $cmd) {
            self::executeAndReport($cmd, $hubUrl, $authHeaders);
        }

        return $decoded;
    }

    private static function executeAndReport(array $cmd, string $hubUrl, array $authHeaders): void
    {
        $commandId = (int) ($cmd['id'] ?? 0);
        $action    = sanitize_text_field($cmd['action'] ?? $cmd['command'] ?? '');
        $params    = (array) ($cmd['params'] ?? $cmd['payload'] ?? []);

        if (!$action) {
            return;
        }

        $result = SiteHub_Executor::run($action, $params);

        // Sign the result report
        $reportAuth = SiteHub_Auth::signRequest($result);

        wp_remote_post($hubUrl, [
            'timeout' => 15,
            'headers' => [
                'Content-Type'       => 'application/json',
                'Accept'             => 'application/json',
                'X-SiteHub-Agent-Id' => $reportAuth['agent_id'],
                'X-SiteHub-Sig'      => $reportAuth['signature'],
                'X-SiteHub-Ts'       => $reportAuth['timestamp'],
                'X-SiteHub-Nonce'    => $reportAuth['nonce'],
            ],
            'body' => wp_json_encode([
                'command_id'     => $commandId,
                'command_status' => $result['status'] === 'success' ? 'completed' : 'failed',
                'command_result' => $result,
            ]),
        ]);
    }
}
