<?php
defined('ABSPATH') || exit;

/**
 * Manages all WP-Cron schedules for SiteHub Agent v2.
 *
 * Jobs:
 *   sitehub_heartbeat_cron  — every 5 min
 *   sitehub_daily_scan      — daily
 *   sitehub_weekly_report   — weekly
 *   sitehub_health_check    — hourly
 */
class SiteHub_Scheduler
{
    const HEARTBEAT  = 'sitehub_heartbeat_cron';
    const DAILY_SCAN = 'sitehub_daily_scan';
    const WEEKLY_RPT = 'sitehub_weekly_report';
    const HEALTH_CHK = 'sitehub_health_check';

    public static function init(): void
    {
        add_action(self::HEARTBEAT,  [SiteHub_Heartbeat::class, 'sendHeartbeat']);
        add_action(self::DAILY_SCAN, [self::class, 'runDailyScan']);
        add_action(self::WEEKLY_RPT, [self::class, 'runWeeklyReport']);
        add_action(self::HEALTH_CHK, [self::class, 'runHealthCheck']);
    }

    public static function schedule(): void
    {
        if (!wp_next_scheduled(self::HEARTBEAT)) {
            wp_schedule_event(time(), 'sitehub_five_minutes', self::HEARTBEAT);
        }
        if (!wp_next_scheduled(self::DAILY_SCAN)) {
            wp_schedule_event(time(), 'daily', self::DAILY_SCAN);
        }
        if (!wp_next_scheduled(self::WEEKLY_RPT)) {
            wp_schedule_event(time(), 'weekly', self::WEEKLY_RPT);
        }
        if (!wp_next_scheduled(self::HEALTH_CHK)) {
            wp_schedule_event(time(), 'hourly', self::HEALTH_CHK);
        }
    }

    public static function unschedule(): void
    {
        foreach ([self::HEARTBEAT, self::DAILY_SCAN, self::WEEKLY_RPT, self::HEALTH_CHK] as $hook) {
            $timestamp = wp_next_scheduled($hook);
            if ($timestamp) {
                wp_unschedule_event($timestamp, $hook);
            }
            wp_clear_scheduled_hook($hook);
        }
    }

    // -------------------------------------------------------------------------
    // Job handlers

    public static function runDailyScan(): void
    {
        if (!SiteHub_Settings::isConfigured()) {
            return;
        }
        // Collect full site info and push to hub
        $data = SiteHub_Health::collectSiteInfo();
        SiteHub_Logger::log('daily_scan', 'completed', ['detail' => 'plugins:' . count($data['active_plugins'] ?? [])]);
    }

    public static function runWeeklyReport(): void
    {
        if (!SiteHub_Settings::isConfigured()) {
            return;
        }
        $data = SiteHub_Health::collectPerformanceMetrics();
        SiteHub_Logger::log('weekly_report', 'completed', ['detail' => 'memory:' . ($data['memory_usage'] ?? '?')]);
    }

    public static function runHealthCheck(): void
    {
        if (!SiteHub_Settings::isConfigured()) {
            return;
        }
        $health = SiteHub_Health::collect();
        $alerts = count($health['security_alerts'] ?? []);
        SiteHub_Logger::log('health_check', 'completed', ['detail' => "alerts:{$alerts}"]);
    }
}
