<?php
defined('ABSPATH') || exit;

/**
 * Execution Layer — validates capability whitelist, wraps command execution,
 * records timing, and logs every execution via SiteHub_Logger.
 */
class SiteHub_Executor
{
    /**
     * Execute a capability request.
     *
     * @param string $action  Capability/action name
     * @param array  $params  Action parameters
     * @return array          v2 response: {status, data, execution_time}
     */
    public static function run(string $action, array $params = []): array
    {
        $start = microtime(true);

        SiteHub_Logger::log($action, 'started');

        // Capability whitelist check
        if (!SiteHub_Capability_Registry::isAllowed($action)) {
            $ms = self::elapsed($start);
            SiteHub_Logger::log($action, 'rejected', ['execution_time' => $ms, 'detail' => 'unknown capability']);
            return self::error('invalid capability', 403, $ms);
        }

        try {
            $result = SiteHub_Commands::execute($action, $params);
            $ms     = self::elapsed($start);

            if ($result['success'] ?? false) {
                SiteHub_Logger::log($action, 'completed', ['execution_time' => $ms]);
                return self::success($result['result'] ?? $result['data'] ?? [], $ms);
            }

            $detail = $result['error'] ?? 'execution failed';
            SiteHub_Logger::log($action, 'failed', ['execution_time' => $ms, 'detail' => $detail]);
            return self::error($detail, 422, $ms);

        } catch (\Throwable $e) {
            $ms = self::elapsed($start);
            SiteHub_Logger::log($action, 'failed', ['execution_time' => $ms, 'detail' => $e->getMessage()]);
            return self::error($e->getMessage(), 500, $ms);
        }
    }

    // -------------------------------------------------------------------------

    private static function elapsed(float $start): string
    {
        return round((microtime(true) - $start) * 1000, 2) . 'ms';
    }

    public static function success(mixed $data, string $executionTime = '0ms'): array
    {
        return [
            'status'         => 'success',
            'data'           => $data,
            'execution_time' => $executionTime,
        ];
    }

    public static function error(string $message, int $code = 400, string $executionTime = '0ms'): array
    {
        return [
            'status'         => 'error',
            'message'        => $message,
            'code'           => $code,
            'execution_time' => $executionTime,
        ];
    }
}
