<?php
defined('ABSPATH') || exit;

/**
 * Security & execution logger.
 * Stores entries in a WP option (ring buffer, max 200 entries).
 */
class SiteHub_Logger
{
    const OPTION = 'sitehub_agent_log';
    const MAX    = 200;

    public static function log(string $action, string $status, array $context = []): void
    {
        $entry = [
            'timestamp'      => gmdate('c'),
            'action'         => $action,
            'status'         => $status,
            'execution_time' => $context['execution_time'] ?? null,
            'detail'         => $context['detail']         ?? null,
        ];

        $log = get_option(self::OPTION, []);
        array_unshift($log, $entry);

        if (count($log) > self::MAX) {
            $log = array_slice($log, 0, self::MAX);
        }

        update_option(self::OPTION, $log, false);
    }

    public static function get(int $limit = 50): array
    {
        return array_slice(get_option(self::OPTION, []), 0, $limit);
    }

    public static function clear(): void
    {
        update_option(self::OPTION, [], false);
    }
}
