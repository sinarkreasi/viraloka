<?php
defined('ABSPATH') || exit;

/**
 * SiteHub Data Collector — v2.1.0
 *
 * Pure data collection layer. No analysis, no scoring, no business logic.
 * Each method maps 1:1 to a capability name.
 *
 * Principle: collect → normalize → return
 */
class SiteHub_Collector
{
    // =========================================================================
    // 1. Site Information
    // =========================================================================

    public static function collect_site_info(): array
    {
        return [
            'site_url'      => home_url(),
            'site_name'     => get_bloginfo('name'),
            'site_language' => get_bloginfo('language'),
            'tagline'       => get_bloginfo('description'),
            'admin_email'   => get_option('blogdescription') ? get_option('admin_email') : '',
            'timezone'      => wp_timezone_string(),
            'date_format'   => get_option('date_format'),
            'time_format'   => get_option('time_format'),
        ];
    }

    public static function collect_wp_info(): array
    {
        return [
            'wp_version'         => get_bloginfo('version'),
            'php_version'        => PHP_VERSION,
            'mysql_version'      => self::getMysqlVersion(),
            'server_software'    => $_SERVER['SERVER_SOFTWARE'] ?? 'unknown',
            'server_ip'          => $_SERVER['SERVER_ADDR'] ?? gethostbyname(gethostname()),
            'max_execution_time' => ini_get('max_execution_time'),
            'memory_limit'       => ini_get('memory_limit'),
            'upload_max_size'    => ini_get('upload_max_filesize'),
            'post_max_size'      => ini_get('post_max_size'),
            'debug_mode'         => defined('WP_DEBUG') && WP_DEBUG,
            'multisite'          => is_multisite(),
        ];
    }

    public static function collect_plugins(): array
    {
        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $all    = get_plugins();
        $active = get_option('active_plugins', []);
        $result = [];
        foreach ($all as $slug => $data) {
            $result[] = [
                'slug'    => $slug,
                'name'    => $data['Name'],
                'version' => $data['Version'],
                'author'  => $data['Author'],
                'active'  => in_array($slug, $active, true),
            ];
        }
        return $result;
    }

    public static function collect_themes(): array
    {
        $active = wp_get_theme();
        $all    = wp_get_themes();
        $result = [];
        foreach ($all as $slug => $theme) {
            $result[] = [
                'slug'    => $slug,
                'name'    => $theme->get('Name'),
                'version' => $theme->get('Version'),
                'author'  => $theme->get('Author'),
                'active'  => $slug === $active->get_stylesheet(),
            ];
        }
        return $result;
    }

    // =========================================================================
    // 2. Content & Structure
    // =========================================================================

    public static function collect_meta_data(array $params = []): array
    {
        global $wpdb;
        $limit = min((int) ($params['limit'] ?? 20), 100);

        $posts = $wpdb->get_results($wpdb->prepare(
            "SELECT ID, post_title, post_type, post_name
             FROM {$wpdb->posts}
             WHERE post_status = 'publish' AND post_type IN ('post','page')
             ORDER BY post_modified DESC LIMIT %d",
            $limit
        ), ARRAY_A);

        $result = [];
        foreach ($posts as $post) {
            $result[] = [
                'id'          => (int) $post['ID'],
                'title'       => $post['post_title'],
                'slug'        => $post['post_name'],
                'post_type'   => $post['post_type'],
                'url'         => get_permalink($post['ID']),
                'description' => get_post_meta($post['ID'], '_yoast_wpseo_metadesc', true)
                              ?: get_post_meta($post['ID'], 'rank_math_description', true)
                              ?: get_post_meta($post['ID'], '_aioseo_description', true)
                              ?: '',
                'canonical'   => get_post_meta($post['ID'], '_yoast_wpseo_canonical', true)
                              ?: get_permalink($post['ID']),
            ];
        }
        return $result;
    }

    public static function collect_headings(array $params = []): array
    {
        global $wpdb;
        $limit = min((int) ($params['limit'] ?? 20), 100);

        $posts = $wpdb->get_results($wpdb->prepare(
            "SELECT ID, post_title, post_content
             FROM {$wpdb->posts}
             WHERE post_status = 'publish' AND post_type IN ('post','page')
             ORDER BY post_modified DESC LIMIT %d",
            $limit
        ), ARRAY_A);

        $result = [];
        foreach ($posts as $post) {
            preg_match_all('/<h([1-6])[^>]*>(.*?)<\/h\1>/is', $post['post_content'], $m);
            $headings = [];
            foreach ($m[1] as $i => $level) {
                $headings[] = ['level' => (int) $level, 'text' => strip_tags($m[2][$i])];
            }
            $result[] = [
                'id'       => (int) $post['ID'],
                'title'    => $post['post_title'],
                'headings' => $headings,
            ];
        }
        return $result;
    }

    public static function collect_internal_links(array $params = []): array
    {
        global $wpdb;
        $limit    = min((int) ($params['limit'] ?? 20), 100);
        $siteHost = parse_url(home_url(), PHP_URL_HOST);

        $posts = $wpdb->get_results($wpdb->prepare(
            "SELECT ID, post_title, post_content
             FROM {$wpdb->posts}
             WHERE post_status = 'publish' AND post_type IN ('post','page')
             ORDER BY post_modified DESC LIMIT %d",
            $limit
        ), ARRAY_A);

        $result = [];
        foreach ($posts as $post) {
            preg_match_all(
                '/<a[^>]+href=["\']([^"\']*)["\'][^>]*>(.*?)<\/a>/is',
                $post['post_content'],
                $m
            );
            $links = [];
            foreach ($m[1] as $i => $href) {
                $host     = parse_url($href, PHP_URL_HOST);
                $internal = !$host || $host === $siteHost;
                $links[]  = [
                    'href'     => $href,
                    'text'     => strip_tags($m[2][$i]),
                    'internal' => $internal,
                ];
            }
            $result[] = [
                'id'    => (int) $post['ID'],
                'title' => $post['post_title'],
                'links' => $links,
            ];
        }
        return $result;
    }

    public static function collect_sitemap(): array
    {
        $sitemapUrl = home_url('/sitemap.xml');
        $response   = wp_remote_get($sitemapUrl, ['timeout' => 10, 'sslverify' => false]);

        if (is_wp_error($response)) {
            return ['url' => $sitemapUrl, 'accessible' => false, 'error' => $response->get_error_message()];
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);

        $urls = [];
        if ($code === 200) {
            preg_match_all('/<loc>(.*?)<\/loc>/i', $body, $m);
            $urls = array_map('trim', $m[1]);
        }

        return [
            'url'        => $sitemapUrl,
            'accessible' => $code === 200,
            'url_count'  => count($urls),
            'urls'       => array_slice($urls, 0, 50),
        ];
    }

    // =========================================================================
    // 3. Performance Data
    // =========================================================================

    public static function collect_performance_metrics(): array
    {
        global $wpdb;
        return [
            'memory_usage_bytes' => memory_get_usage(true),
            'memory_peak_bytes'  => memory_get_peak_usage(true),
            'memory_limit'       => ini_get('memory_limit'),
            'db_queries'         => $wpdb->num_queries,
            'opcache_enabled'    => function_exists('opcache_get_status') && opcache_get_status() !== false,
            'disk_free_bytes'    => @disk_free_space(ABSPATH) ?: null,
            'disk_total_bytes'   => @disk_total_space(ABSPATH) ?: null,
        ];
    }

    public static function collect_asset_sizes(): array
    {
        $uploadsDir = wp_upload_dir();
        $uploadsPath = $uploadsDir['basedir'];

        return [
            'uploads_dir'        => $uploadsPath,
            'uploads_size_bytes' => is_dir($uploadsPath) ? self::dirSize($uploadsPath) : null,
            'plugins_size_bytes' => is_dir(WP_PLUGIN_DIR) ? self::dirSize(WP_PLUGIN_DIR) : null,
            'themes_size_bytes'  => is_dir(get_theme_root()) ? self::dirSize(get_theme_root()) : null,
        ];
    }

    public static function collect_cache_status(): array
    {
        return [
            'object_cache'    => wp_using_ext_object_cache(),
            'opcache_enabled' => function_exists('opcache_get_status') && opcache_get_status() !== false,
            'page_cache'      => defined('WP_CACHE') && WP_CACHE,
            'redis_active'    => class_exists('Redis') || defined('WP_REDIS_HOST'),
            'memcached_active'=> class_exists('Memcached') || class_exists('Memcache'),
        ];
    }

    public static function collect_ttfb(): array
    {
        $start    = microtime(true);
        $response = wp_remote_get(home_url('/'), ['timeout' => 15, 'sslverify' => false]);
        $elapsed  = round((microtime(true) - $start) * 1000, 2);

        if (is_wp_error($response)) {
            return ['ttfb_ms' => null, 'error' => $response->get_error_message()];
        }

        return [
            'ttfb_ms'     => $elapsed,
            'status_code' => wp_remote_retrieve_response_code($response),
            'url'         => home_url('/'),
        ];
    }

    // =========================================================================
    // 4. Security Signals
    // =========================================================================

    public static function collect_http_headers(): array
    {
        $response = wp_remote_get(home_url('/'), ['timeout' => 10, 'sslverify' => false]);

        if (is_wp_error($response)) {
            return ['error' => $response->get_error_message()];
        }

        $headers = wp_remote_retrieve_headers($response)->getAll();

        // Security-relevant headers
        $securityHeaders = [
            'x-frame-options',
            'x-content-type-options',
            'x-xss-protection',
            'strict-transport-security',
            'content-security-policy',
            'referrer-policy',
            'permissions-policy',
        ];

        $result = ['all' => $headers, 'security' => []];
        foreach ($securityHeaders as $h) {
            $result['security'][$h] = $headers[$h] ?? null;
        }

        return $result;
    }

    public static function collect_file_permissions(): array
    {
        $paths = [
            'wp-config.php'  => ABSPATH . 'wp-config.php',
            '.htaccess'      => ABSPATH . '.htaccess',
            'wp-content'     => WP_CONTENT_DIR,
            'wp-admin'       => ABSPATH . 'wp-admin',
            'wp-includes'    => ABSPATH . 'wp-includes',
        ];

        $result = [];
        foreach ($paths as $label => $path) {
            if (!file_exists($path)) {
                $result[$label] = ['exists' => false];
                continue;
            }
            $perms = fileperms($path);
            $result[$label] = [
                'exists'      => true,
                'permissions' => substr(sprintf('%o', $perms), -4),
                'readable'    => is_readable($path),
                'writable'    => is_writable($path),
            ];
        }
        return $result;
    }

    public static function collect_login_endpoint(): array
    {
        $loginUrl = wp_login_url();
        $isDefault = str_contains($loginUrl, 'wp-login.php');

        return [
            'login_url'          => $loginUrl,
            'is_default_path'    => $isDefault,
            'xmlrpc_enabled'     => file_exists(ABSPATH . 'xmlrpc.php'),
            'rest_api_public'    => true, // WP REST is public by default
            'admin_url'          => admin_url(),
        ];
    }

    public static function collect_exposed_files(): array
    {
        $checks = [
            'readme.html'       => ABSPATH . 'readme.html',
            'license.txt'       => ABSPATH . 'license.txt',
            'wp-config-sample'  => ABSPATH . 'wp-config-sample.php',
            'debug.log'         => WP_CONTENT_DIR . '/debug.log',
            'error_log'         => ABSPATH . 'error_log',
        ];

        $result = [];
        foreach ($checks as $label => $path) {
            $result[$label] = file_exists($path);
        }
        return $result;
    }

    // =========================================================================
    // 5. Technical Signals
    // =========================================================================

    public static function collect_robots_txt(): array
    {
        $url      = home_url('/robots.txt');
        $response = wp_remote_get($url, ['timeout' => 10, 'sslverify' => false]);

        if (is_wp_error($response)) {
            return ['url' => $url, 'accessible' => false, 'error' => $response->get_error_message()];
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);

        return [
            'url'         => $url,
            'accessible'  => $code === 200,
            'content'     => $code === 200 ? $body : null,
            'has_sitemap' => $code === 200 && str_contains(strtolower($body), 'sitemap:'),
            'disallows'   => $code === 200 ? self::parseRobotsDisallows($body) : [],
        ];
    }

    public static function collect_canonical_tags(array $params = []): array
    {
        global $wpdb;
        $limit = min((int) ($params['limit'] ?? 20), 100);

        $posts = $wpdb->get_results($wpdb->prepare(
            "SELECT ID, post_title FROM {$wpdb->posts}
             WHERE post_status = 'publish' AND post_type IN ('post','page')
             ORDER BY post_modified DESC LIMIT %d",
            $limit
        ), ARRAY_A);

        $result = [];
        foreach ($posts as $post) {
            $canonical = get_post_meta($post['ID'], '_yoast_wpseo_canonical', true)
                      ?: get_post_meta($post['ID'], 'rank_math_canonical_url', true)
                      ?: get_permalink($post['ID']);
            $result[] = [
                'id'        => (int) $post['ID'],
                'title'     => $post['post_title'],
                'permalink' => get_permalink($post['ID']),
                'canonical' => $canonical,
                'matches'   => rtrim($canonical, '/') === rtrim(get_permalink($post['ID']), '/'),
            ];
        }
        return $result;
    }

    public static function collect_redirects(): array
    {
        global $wpdb;

        // Check for common redirect plugins
        $redirects = [];

        // Redirection plugin table
        $table = $wpdb->prefix . 'redirection_items';
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table}'") === $table) {
            $rows = $wpdb->get_results(
                "SELECT url, action_data, status FROM {$table} WHERE status = 'enabled' LIMIT 50",
                ARRAY_A
            );
            foreach ((array) $rows as $r) {
                $redirects[] = [
                    'source'  => $r['url'],
                    'target'  => $r['action_data'],
                    'status'  => $r['status'],
                    'plugin'  => 'redirection',
                ];
            }
        }

        // Yoast premium redirects
        $yoastTable = $wpdb->prefix . 'yoast_redirects';
        if ($wpdb->get_var("SHOW TABLES LIKE '{$yoastTable}'") === $yoastTable) {
            $rows = $wpdb->get_results(
                "SELECT origin, url, type FROM {$yoastTable} LIMIT 50",
                ARRAY_A
            );
            foreach ((array) $rows as $r) {
                $redirects[] = [
                    'source' => $r['origin'],
                    'target' => $r['url'],
                    'type'   => $r['type'],
                    'plugin' => 'yoast',
                ];
            }
        }

        return [
            'count'     => count($redirects),
            'redirects' => $redirects,
        ];
    }

    public static function collect_status_codes(array $params = []): array
    {
        global $wpdb;
        $limit = min((int) ($params['limit'] ?? 10), 30);

        $posts = $wpdb->get_results($wpdb->prepare(
            "SELECT ID, post_title FROM {$wpdb->posts}
             WHERE post_status = 'publish' AND post_type IN ('post','page')
             ORDER BY post_modified DESC LIMIT %d",
            $limit
        ), ARRAY_A);

        $result = [];
        foreach ($posts as $post) {
            $url      = get_permalink($post['ID']);
            $response = wp_remote_head($url, ['timeout' => 8, 'sslverify' => false, 'redirection' => 0]);
            $result[] = [
                'id'          => (int) $post['ID'],
                'title'       => $post['post_title'],
                'url'         => $url,
                'status_code' => is_wp_error($response) ? null : wp_remote_retrieve_response_code($response),
                'error'       => is_wp_error($response) ? $response->get_error_message() : null,
            ];
        }
        return $result;
    }

    // =========================================================================
    // 6. Post-Type Based Scanning (v2.1.1)
    // =========================================================================

    /**
     * Returns all registered public post types with counts.
     */
    public static function collect_post_types(): array
    {
        $types  = get_post_types(['public' => true], 'objects');
        $result = [];
        foreach ($types as $slug => $obj) {
            $count = wp_count_posts($slug);
            $result[] = [
                'slug'       => $slug,
                'label'      => $obj->label,
                'singular'   => $obj->labels->singular_name ?? $obj->label,
                'published'  => (int) ($count->publish ?? 0),
                'draft'      => (int) ($count->draft ?? 0),
                'builtin'    => $obj->_builtin,
            ];
        }
        return $result;
    }

    /**
     * Fetch content items for a specific post type with optional filters.
     *
     * Params:
     *   post_type  string  (required)
     *   status     string  published|draft|any  (default: publish)
     *   limit      int     max 100              (default: 50)
     *   offset     int                          (default: 0)
     *   category   string  taxonomy term slug   (optional)
     *   date_after string  Y-m-d                (optional)
     */
    public static function collect_content_by_type(array $params = []): array
    {
        global $wpdb;

        $postType = sanitize_key($params['post_type'] ?? 'post');
        $status   = in_array($params['status'] ?? 'publish', ['publish', 'draft', 'any'], true)
                    ? ($params['status'] ?? 'publish') : 'publish';
        $limit    = min((int) ($params['limit'] ?? 50), 100);
        $offset   = max(0, (int) ($params['offset'] ?? 0));

        $args = [
            'post_type'      => $postType,
            'post_status'    => $status,
            'posts_per_page' => $limit,
            'offset'         => $offset,
            'orderby'        => 'modified',
            'order'          => 'DESC',
            'no_found_rows'  => false,
        ];

        if (!empty($params['category'])) {
            $args['tax_query'] = [[
                'taxonomy' => 'category',
                'field'    => 'slug',
                'terms'    => sanitize_key($params['category']),
            ]];
        }

        if (!empty($params['date_after'])) {
            $args['date_query'] = [['after' => sanitize_text_field($params['date_after'])]];
        }

        $query = new \WP_Query($args);
        $items = [];

        foreach ($query->posts as $post) {
            $items[] = [
                'id'          => $post->ID,
                'title'       => $post->post_title,
                'slug'        => $post->post_name,
                'url'         => get_permalink($post->ID),
                'post_type'   => $post->post_type,
                'status'      => $post->post_status,
                'modified'    => $post->post_modified,
                'description' => get_post_meta($post->ID, '_yoast_wpseo_metadesc', true)
                              ?: get_post_meta($post->ID, 'rank_math_description', true)
                              ?: '',
                'canonical'   => get_post_meta($post->ID, '_yoast_wpseo_canonical', true)
                              ?: get_permalink($post->ID),
                'word_count'  => str_word_count(wp_strip_all_tags($post->post_content)),
                'has_featured_image' => (bool) get_post_thumbnail_id($post->ID),
            ];
        }

        return [
            'post_type'   => $postType,
            'total_found' => (int) $query->found_posts,
            'returned'    => count($items),
            'offset'      => $offset,
            'items'       => $items,
        ];
    }

    private static function getMysqlVersion(): string
    {
        global $wpdb;
        return (string) $wpdb->get_var('SELECT VERSION()');
    }

    private static function dirSize(string $path): int
    {
        $size = 0;
        try {
            $iter = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS),
                RecursiveIteratorIterator::LEAVES_ONLY
            );
            foreach ($iter as $file) {
                if ($file->isFile()) {
                    $size += $file->getSize();
                }
            }
        } catch (\Throwable) {
            // Ignore permission errors
        }
        return $size;
    }

    private static function parseRobotsDisallows(string $content): array
    {
        $disallows = [];
        foreach (explode("\n", $content) as $line) {
            $line = trim($line);
            if (stripos($line, 'Disallow:') === 0) {
                $path = trim(substr($line, 9));
                if ($path !== '') {
                    $disallows[] = $path;
                }
            }
        }
        return $disallows;
    }
}
