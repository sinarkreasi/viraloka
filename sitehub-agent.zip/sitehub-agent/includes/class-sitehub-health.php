<?php
defined('ABSPATH') || exit;

/**
 * Health & data collection for SiteHub Agent v2.
 */
class SiteHub_Health
{
    /**
     * Full health payload (heartbeat).
     */
    public static function collect(): array
    {
        return [
            'wp_version'      => get_bloginfo('version'),
            'php_version'     => PHP_VERSION,
            'server_ip'       => self::getServerIp(),
            'site_url'        => home_url(),
            'pending_updates' => self::getPendingUpdates(),
            'security_alerts' => self::getSecurityAlerts(),
            'backup_status'   => [],
            'active_plugins'  => self::getActivePlugins(),
            'disk_usage'      => self::getDiskUsage(),
        ];
    }

    /**
     * Structured site info (capability: collect_site_info).
     */
    public static function collectSiteInfo(): array
    {
        return [
            'site_url'       => home_url(),
            'site_name'      => get_bloginfo('name'),
            'site_language'  => get_bloginfo('language'),
            'wp_version'     => get_bloginfo('version'),
            'php_version'    => PHP_VERSION,
            'server_ip'      => self::getServerIp(),
            'timezone'       => wp_timezone_string(),
            'active_theme'   => self::getActiveTheme(),
            'active_plugins' => self::getActivePlugins(),
            'pending_updates'=> self::getPendingUpdates(),
            'security_alerts'=> self::getSecurityAlerts(),
            'disk_usage'     => self::getDiskUsage(),
            'agent_id'       => SiteHub_Auth::getAgentId(),
            'agent_version'  => SITEHUB_AGENT_VERSION,
        ];
    }

    /**
     * Performance metrics (capability: collect_performance_metrics).
     */
    public static function collectPerformanceMetrics(): array
    {
        global $wpdb;

        $memoryUsage = memory_get_usage(true);
        $memoryPeak  = memory_get_peak_usage(true);
        $memoryLimit = ini_get('memory_limit');

        return [
            'memory_usage'       => self::formatBytes($memoryUsage),
            'memory_peak'        => self::formatBytes($memoryPeak),
            'memory_limit'       => $memoryLimit,
            'memory_usage_bytes' => $memoryUsage,
            'php_version'        => PHP_VERSION,
            'db_queries'         => $wpdb->num_queries,
            'db_prefix'          => $wpdb->prefix,
            'server_software'    => $_SERVER['SERVER_SOFTWARE'] ?? 'unknown',
            'max_execution_time' => ini_get('max_execution_time'),
            'upload_max_size'    => ini_get('upload_max_filesize'),
            'post_max_size'      => ini_get('post_max_size'),
            'disk_usage'         => self::getDiskUsage(),
            'opcache_enabled'    => function_exists('opcache_get_status') && opcache_get_status() !== false,
        ];
    }

    /**
     * Content analysis (capability: content_analysis).
     *
     * Returns per-page SEO signals + site-level GEO/AEO flags used by
     * SiteHub SEO engines: Technical, Content, GEO, AEO.
     */
    public static function contentAnalysis(array $params = []): array
    {
        global $wpdb;

        $limit = min((int) ($params['limit'] ?? 50), 200);

        // ── Per-page signals (Content SEO engine) ────────────────────────────
        $posts = $wpdb->get_results($wpdb->prepare(
            "SELECT ID, post_title, post_content, post_type, post_status
             FROM {$wpdb->posts}
             WHERE post_status = 'publish'
               AND post_type IN ('post','page')
             ORDER BY post_modified DESC
             LIMIT %d",
            $limit
        ), ARRAY_A);

        $pages              = [];
        $imagesTotal        = 0;
        $imagesMissingAlt   = 0;

        foreach ($posts as $post) {
            $content  = $post['post_content'] ?? '';
            $title    = $post['post_title']   ?? '';

            // H1 count — post title counts as H1; also check content
            $h1InContent = preg_match_all('/<h1[\s>]/i', $content);
            $h1Count     = 1 + $h1InContent; // title = 1 implicit H1

            // Meta description via Yoast / RankMath / AIOSEO / plain excerpt
            $metaDesc = get_post_meta($post['ID'], '_yoast_wpseo_metadesc', true)
                     ?: get_post_meta($post['ID'], 'rank_math_description', true)
                     ?: get_post_meta($post['ID'], '_aioseo_description', true)
                     ?: wp_trim_words(wp_strip_all_tags($content), 25, '');

            // Word count
            $wordCount = str_word_count(wp_strip_all_tags($content));

            // Internal links
            $siteHost      = parse_url(home_url(), PHP_URL_HOST);
            $internalLinks = preg_match_all(
                '/<a[^>]+href=["\']https?:\/\/' . preg_quote($siteHost, '/') . '[^"\']*["\'][^>]*>/i',
                $content
            );

            // Images
            $imgMatches = [];
            preg_match_all('/<img[^>]+>/i', $content, $imgMatches);
            $imgCount = count($imgMatches[0]);
            $imagesTotal += $imgCount;
            foreach ($imgMatches[0] as $img) {
                if (!preg_match('/alt=["\'][^"\']+["\']/i', $img)) {
                    $imagesMissingAlt++;
                }
            }

            // Heading depth (max heading level used: H2=2, H3=3, etc.)
            $maxDepth = 1;
            for ($h = 2; $h <= 6; $h++) {
                if (preg_match('/<h' . $h . '[\s>]/i', $content)) {
                    $maxDepth = $h;
                }
            }

            $pages[] = [
                'id'             => (int) $post['ID'],
                'title'          => $title,
                'post_type'      => $post['post_type'],
                'h1_count'       => $h1Count,
                'meta_description'=> $metaDesc,
                'word_count'     => $wordCount,
                'internal_links' => $internalLinks,
                'heading_depth'  => $maxDepth,
            ];
        }

        // ── Heading depth average (GEO engine) ───────────────────────────────
        $avgHeadingDepth = count($pages)
            ? round(array_sum(array_column($pages, 'heading_depth')) / count($pages), 1)
            : 0;

        // ── Schema markup detection (GEO + AEO engines) ──────────────────────
        $frontPage   = get_option('page_on_front') ? get_post(get_option('page_on_front')) : null;
        $sampleContent = implode(' ', array_column($posts, 'post_content'));

        $hasSchemaMarkup    = (bool) preg_match('/"@type"\s*:/i', $sampleContent)
                           || (bool) preg_match('/itemtype=["\']https?:\/\/schema\.org/i', $sampleContent);
        $hasFaqSchema       = (bool) preg_match('/"@type"\s*:\s*"FAQPage"/i', $sampleContent)
                           || (bool) preg_match('/itemtype=["\']https?:\/\/schema\.org\/FAQPage/i', $sampleContent);
        $hasHowToSchema     = (bool) preg_match('/"@type"\s*:\s*"HowTo"/i', $sampleContent);
        $hasBreadcrumbSchema= (bool) preg_match('/"@type"\s*:\s*"BreadcrumbList"/i', $sampleContent);

        // ── About page detection (GEO engine) ────────────────────────────────
        $hasAboutPage = (bool) $wpdb->get_var(
            "SELECT ID FROM {$wpdb->posts}
             WHERE post_status = 'publish'
               AND post_type IN ('post','page')
               AND (post_name LIKE '%about%' OR post_title LIKE '%About%')
             LIMIT 1"
        );

        // ── Author info detection (GEO engine) ───────────────────────────────
        $hasAuthorInfo = (bool) $wpdb->get_var(
            "SELECT u.ID FROM {$wpdb->users} u
             INNER JOIN {$wpdb->usermeta} um ON u.ID = um.user_id
             WHERE um.meta_key = 'description' AND um.meta_value != ''
             LIMIT 1"
        );

        // ── Topic clusters (GEO engine) ───────────────────────────────────────
        // Count categories with ≥3 published posts as a proxy for topic clusters
        $topicClusters = (int) $wpdb->get_var(
            "SELECT COUNT(DISTINCT t.term_id)
             FROM {$wpdb->terms} t
             INNER JOIN {$wpdb->term_taxonomy} tt ON t.term_id = tt.term_id
             WHERE tt.taxonomy = 'category' AND tt.count >= 3"
        );

        // ── Q&A pages (AEO engine) ────────────────────────────────────────────
        $qaPages = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts}
             WHERE post_status = 'publish'
               AND post_type IN ('post','page')
               AND (post_name LIKE '%faq%' OR post_title LIKE '%FAQ%'
                    OR post_title LIKE '%question%' OR post_name LIKE '%question%')"
        );

        // ── Definition blocks (AEO engine) ────────────────────────────────────
        // Look for <p> directly after a heading — common featured-snippet pattern
        $hasDefinitionBlocks = (bool) preg_match('/<h[2-4][^>]*>.*?<\/h[2-4]>\s*<p>/is', $sampleContent);

        return [
            // Content SEO
            'pages'              => $pages,
            'images_missing_alt' => $imagesMissingAlt,
            'images_total'       => $imagesTotal,

            // GEO signals
            'has_schema_markup'  => $hasSchemaMarkup,
            'has_about_page'     => $hasAboutPage,
            'has_author_info'    => $hasAuthorInfo,
            'topic_clusters'     => $topicClusters,
            'avg_heading_depth'  => $avgHeadingDepth,

            // AEO signals
            'has_faq_schema'         => $hasFaqSchema,
            'has_howto_schema'       => $hasHowToSchema,
            'has_breadcrumb_schema'  => $hasBreadcrumbSchema,
            'qa_pages'               => $qaPages,
            'has_definition_blocks'  => $hasDefinitionBlocks,
        ];
    }

    // -------------------------------------------------------------------------
    // Private helpers

    private static function getServerIp(): string
    {
        return $_SERVER['SERVER_ADDR'] ?? gethostbyname(gethostname());
    }

    private static function getActiveTheme(): array
    {
        $theme = wp_get_theme();
        return [
            'name'    => $theme->get('Name'),
            'version' => $theme->get('Version'),
            'author'  => $theme->get('Author'),
        ];
    }

    private static function getPendingUpdates(): array
    {
        if (!function_exists('get_core_updates')) {
            require_once ABSPATH . 'wp-admin/includes/update.php';
        }

        $coreUpdates   = get_core_updates();
        $coreAvailable = false;
        foreach ((array) $coreUpdates as $update) {
            if (isset($update->response) && $update->response === 'upgrade') {
                $coreAvailable = true;
                break;
            }
        }

        return [
            'core'    => $coreAvailable,
            'plugins' => count(get_plugin_updates()),
            'themes'  => count(get_theme_updates()),
        ];
    }

    private static function getSecurityAlerts(): array
    {
        $alerts = [];

        if (version_compare(PHP_VERSION, '8.0', '<')) {
            $alerts[] = 'PHP version ' . PHP_VERSION . ' is outdated (8.0+ recommended)';
        }

        $wpVersion = get_bloginfo('version');
        if (version_compare($wpVersion, '6.0', '<')) {
            $alerts[] = 'WordPress ' . $wpVersion . ' is outdated';
        }

        if (!defined('DISALLOW_FILE_EDIT') || !DISALLOW_FILE_EDIT) {
            $alerts[] = 'File editor is enabled (DISALLOW_FILE_EDIT not set)';
        }

        if (defined('WP_DEBUG_LOG') && WP_DEBUG_LOG === true) {
            $alerts[] = 'WP_DEBUG_LOG is enabled';
        }

        return $alerts;
    }

    private static function getActivePlugins(): array
    {
        $plugins = get_option('active_plugins', []);
        $result  = [];
        foreach ($plugins as $plugin) {
            $data     = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin, false, false);
            $result[] = [
                'slug'    => $plugin,
                'name'    => $data['Name'] ?? $plugin,
                'version' => $data['Version'] ?? '?',
            ];
        }
        return $result;
    }

    private static function getDiskUsage(): array
    {
        $free  = @disk_free_space(ABSPATH);
        $total = @disk_total_space(ABSPATH);
        return [
            'free_bytes'  => $free  !== false ? (int) $free  : null,
            'total_bytes' => $total !== false ? (int) $total : null,
        ];
    }

    private static function formatBytes(int $bytes): string
    {
        if ($bytes >= 1073741824) {
            return round($bytes / 1073741824, 2) . ' GB';
        }
        if ($bytes >= 1048576) {
            return round($bytes / 1048576, 2) . ' MB';
        }
        return round($bytes / 1024, 2) . ' KB';
    }
}
