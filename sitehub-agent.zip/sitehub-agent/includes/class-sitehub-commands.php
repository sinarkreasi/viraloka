<?php
defined('ABSPATH') || exit;

if (!class_exists('WP_Upgrader_Skin')) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
}

/**
 * Command handlers — maps capability names to execution logic.
 * Returns: ['success' => bool, 'result' => mixed] or ['success' => false, 'error' => string]
 */
class SiteHub_Commands
{
    public static function execute(string $action, array $params = []): array
    {
        try {
            return match ($action) {
                'collect_site_info'           => self::collectSiteInfo(),
                'collect_performance_metrics' => self::collectPerformanceMetrics(),
                'scan_plugins'                => self::scanPlugins($params),
                'scan_filesystem'             => self::scanFilesystem($params),
                'read_database'               => self::readDatabase($params),
                'content_analysis'            => self::contentAnalysis($params),
                'fetch_health'                => self::fetchHealth(),
                'execute_command'             => self::executeCommand($params),
                'update_core'                 => self::updateCore(),
                'update_plugins'              => self::updatePlugins($params),
                'update_themes'               => self::updateThemes($params),
                'trigger_backup'              => self::triggerBackup($params),
                'activate_plugin'             => self::activatePlugin($params),
                'deactivate_plugin'           => self::deactivatePlugin($params),
                default => ['success' => false, 'error' => "Unknown capability: {$action}"],
            };
        } catch (\Throwable $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    // -------------------------------------------------------------------------
    // Data Collection

    private static function collectSiteInfo(): array
    {
        return ['success' => true, 'result' => SiteHub_Health::collectSiteInfo()];
    }

    private static function collectPerformanceMetrics(): array
    {
        return ['success' => true, 'result' => SiteHub_Health::collectPerformanceMetrics()];
    }

    private static function scanPlugins(array $params): array
    {
        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $all    = get_plugins();
        $active = get_option('active_plugins', []);
        $updates = get_plugin_updates();
        $result = [];
        foreach ($all as $slug => $data) {
            $result[] = [
                'slug'             => $slug,
                'name'             => $data['Name'],
                'version'          => $data['Version'],
                'author'           => $data['Author'],
                'active'           => in_array($slug, $active, true),
                'update_available' => isset($updates[$slug]),
                'new_version'      => $updates[$slug]->update->new_version ?? null,
            ];
        }
        return ['success' => true, 'result' => $result];
    }

    private static function scanFilesystem(array $params): array
    {
        $path     = sanitize_text_field($params['path'] ?? ABSPATH);
        $depth    = min((int) ($params['depth'] ?? 1), 3);
        $realPath = realpath($path);
        $realBase = realpath(ABSPATH);
        if ($realPath === false || strpos($realPath, $realBase) !== 0) {
            return ['success' => false, 'error' => 'Path outside ABSPATH is not allowed.'];
        }
        return ['success' => true, 'result' => self::scanDir($realPath, $depth)];
    }

    private static function scanDir(string $path, int $depth): array
    {
        if ($depth < 0 || !is_dir($path)) {
            return [];
        }
        $items   = [];
        $entries = @scandir($path);
        if (!$entries) {
            return [];
        }
        foreach ($entries as $entry) {
            if ($entry === '.' || $entry === '..') {
                continue;
            }
            $full = $path . DIRECTORY_SEPARATOR . $entry;
            $item = [
                'name'     => $entry,
                'type'     => is_dir($full) ? 'dir' : 'file',
                'size'     => is_file($full) ? filesize($full) : null,
                'modified' => filemtime($full),
            ];
            if (is_dir($full) && $depth > 0) {
                $item['children'] = self::scanDir($full, $depth - 1);
            }
            $items[] = $item;
        }
        return $items;
    }

    private static function readDatabase(array $params): array
    {
        global $wpdb;
        $query = sanitize_text_field($params['query'] ?? '');
        if (empty($query)) {
            return ['success' => false, 'error' => 'query param required.'];
        }
        if (!preg_match('/^\s*SELECT\s/i', $query)) {
            return ['success' => false, 'error' => 'Only SELECT queries are allowed.'];
        }
        $query = str_replace('{prefix}', $wpdb->prefix, $query);
        $rows  = $wpdb->get_results($query, ARRAY_A);
        if ($wpdb->last_error) {
            return ['success' => false, 'error' => $wpdb->last_error];
        }
        return ['success' => true, 'result' => $rows];
    }

    private static function contentAnalysis(array $params): array
    {
        return ['success' => true, 'result' => SiteHub_Health::contentAnalysis($params)];
    }

    private static function fetchHealth(): array
    {
        return ['success' => true, 'result' => SiteHub_Health::collect()];
    }

    private static function executeCommand(array $params): array
    {
        $cmd = sanitize_text_field($params['cmd'] ?? '');
        if (empty($cmd)) {
            return ['success' => false, 'error' => 'cmd param required.'];
        }
        $result = apply_filters('sitehub_execute_command', null, $cmd, $params);
        if ($result !== null) {
            return ['success' => true, 'result' => $result];
        }
        return ['success' => false, 'error' => 'No handler registered for this command.'];
    }

    // -------------------------------------------------------------------------
    // Remote Management

    private static function updateCore(): array
    {
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/update.php';
        $updates = get_core_updates();
        if (empty($updates)) {
            return ['success' => true, 'result' => 'WordPress is already up to date.'];
        }
        $update = reset($updates);
        if ($update->response !== 'upgrade') {
            return ['success' => true, 'result' => 'No upgrade available.'];
        }
        $upgrader = new Core_Upgrader(new SiteHub_Upgrader_Skin());
        $result   = $upgrader->upgrade($update);
        if (is_wp_error($result)) {
            return ['success' => false, 'error' => $result->get_error_message()];
        }
        return ['success' => true, 'result' => 'WordPress core updated to ' . $update->version];
    }

    private static function updatePlugins(array $params): array
    {
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/update.php';
        $updates = get_plugin_updates();
        if (empty($updates)) {
            return ['success' => true, 'result' => 'All plugins are up to date.'];
        }
        $slug = $params['slug'] ?? null;
        if ($slug) {
            if (!isset($updates[$slug])) {
                return ['success' => true, 'result' => "Plugin {$slug} is already up to date."];
            }
            $updates = [$slug => $updates[$slug]];
        }
        $upgrader = new Plugin_Upgrader(new SiteHub_Upgrader_Skin());
        $slugs    = array_keys($updates);
        $result   = $upgrader->bulk_upgrade($slugs);
        $errors   = [];
        foreach ($result as $plugin => $res) {
            if (is_wp_error($res)) {
                $errors[] = $plugin . ': ' . $res->get_error_message();
            }
        }
        if (!empty($errors)) {
            return ['success' => false, 'error' => implode('; ', $errors)];
        }
        return ['success' => true, 'result' => count($slugs) . ' plugin(s) updated.'];
    }

    private static function updateThemes(array $params): array
    {
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/update.php';
        $updates = get_theme_updates();
        if (empty($updates)) {
            return ['success' => true, 'result' => 'All themes are up to date.'];
        }
        $slug = $params['slug'] ?? null;
        if ($slug) {
            if (!isset($updates[$slug])) {
                return ['success' => true, 'result' => "Theme {$slug} is already up to date."];
            }
            $updates = [$slug => $updates[$slug]];
        }
        $upgrader = new Theme_Upgrader(new SiteHub_Upgrader_Skin());
        $slugs    = array_keys($updates);
        $result   = $upgrader->bulk_upgrade($slugs);
        $errors   = [];
        foreach ($result as $theme => $res) {
            if (is_wp_error($res)) {
                $errors[] = $theme . ': ' . $res->get_error_message();
            }
        }
        if (!empty($errors)) {
            return ['success' => false, 'error' => implode('; ', $errors)];
        }
        return ['success' => true, 'result' => count($slugs) . ' theme(s) updated.'];
    }

    private static function triggerBackup(array $params): array
    {
        if (class_exists('UpdraftPlus')) {
            global $updraftplus;
            $updraftplus->boot_backup(true, true, false, false, 'sitehub');
            return ['success' => true, 'result' => 'UpdraftPlus backup triggered.'];
        }
        if (class_exists('BackWPup')) {
            do_action('backwpup_run_job', $params['job_id'] ?? 0);
            return ['success' => true, 'result' => 'BackWPup job triggered.'];
        }
        do_action('sitehub_trigger_backup', $params);
        return ['success' => true, 'result' => 'Backup action fired (sitehub_trigger_backup).'];
    }

    private static function activatePlugin(array $params): array
    {
        $slug = sanitize_text_field($params['slug'] ?? '');
        if (empty($slug)) {
            return ['success' => false, 'error' => 'Plugin slug required.'];
        }
        if (!function_exists('activate_plugin')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $result = activate_plugin($slug);
        if (is_wp_error($result)) {
            return ['success' => false, 'error' => $result->get_error_message()];
        }
        return ['success' => true, 'result' => "Plugin {$slug} activated."];
    }

    private static function deactivatePlugin(array $params): array
    {
        $slug = sanitize_text_field($params['slug'] ?? '');
        if (empty($slug)) {
            return ['success' => false, 'error' => 'Plugin slug required.'];
        }
        if (!function_exists('deactivate_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        deactivate_plugins($slug);
        return ['success' => true, 'result' => "Plugin {$slug} deactivated."];
    }
}

/**
 * Silent upgrader skin — suppresses output during remote upgrades.
 */
class SiteHub_Upgrader_Skin extends WP_Upgrader_Skin
{
    public function feedback($string, ...$args): void {}
    public function header(): void {}
    public function footer(): void {}
    public function error($errors): void {}
}
