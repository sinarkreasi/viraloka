<?php
defined('ABSPATH') || exit;

/**
 * Capability Registry — v2.1.0
 *
 * Defines all capabilities this agent exposes.
 * Capabilities are grouped by category per spec v2.1.0.
 *
 * Categories:
 *   1. Site Information
 *   2. Content & Structure
 *   3. Performance Data
 *   4. Security Signals
 *   5. Technical Signals
 *   6. Remote Management (legacy, kept for backward compat)
 */
class SiteHub_Capability_Registry
{
    /**
     * Data collection capabilities (spec v2.1.0).
     * These are served by SiteHub_Collector via the /collect endpoint.
     */
    private static array $collectCapabilities = [
        // 1. Site Information
        'collect_site_info',
        'collect_wp_info',
        'collect_plugins',
        'collect_themes',

        // 2. Content & Structure
        'collect_meta_data',
        'collect_headings',
        'collect_internal_links',
        'collect_sitemap',

        // 3. Performance Data
        'collect_performance_metrics',
        'collect_asset_sizes',
        'collect_cache_status',
        'collect_ttfb',

        // 4. Security Signals
        'collect_http_headers',
        'collect_file_permissions',
        'collect_login_endpoint',
        'collect_exposed_files',

        // 5. Technical Signals
        'collect_robots_txt',
        'collect_canonical_tags',
        'collect_redirects',
        'collect_status_codes',

        // 6. Post-Type Based Scanning (v2.1.1)
        'collect_post_types',
        'collect_content_by_type',
    ];

    /**
     * Remote management capabilities (legacy — served by SiteHub_Commands via /execute).
     */
    private static array $managementCapabilities = [
        'fetch_health',
        'scan_plugins',
        'scan_filesystem',
        'read_database',
        'content_analysis',
        'execute_command',
        'update_core',
        'update_plugins',
        'update_themes',
        'trigger_backup',
        'activate_plugin',
        'deactivate_plugin',
    ];

    /** Extra capabilities registered at runtime (e.g. by other plugins) */
    private static array $extra = [];

    /**
     * Register an additional capability at runtime.
     */
    public static function register(string $capability): void
    {
        $all = self::getAll();
        if (!in_array($capability, $all, true) && !in_array($capability, self::$extra, true)) {
            self::$extra[] = $capability;
        }
    }

    /**
     * All capabilities (collect + management + extra).
     */
    public static function getAll(): array
    {
        return array_values(array_unique(array_merge(
            self::$collectCapabilities,
            self::$managementCapabilities,
            self::$extra
        )));
    }

    /**
     * Only data collection capabilities (used by /collect endpoint).
     */
    public static function getCollectCapabilities(): array
    {
        return array_merge(self::$collectCapabilities, array_filter(
            self::$extra,
            fn($c) => str_starts_with($c, 'collect_')
        ));
    }

    /**
     * Check if a capability is available.
     */
    public static function isAllowed(string $capability): bool
    {
        return in_array($capability, self::getAll(), true);
    }

    /**
     * Check if a capability is a data collection capability.
     */
    public static function isCollectCapability(string $capability): bool
    {
        return in_array($capability, self::getCollectCapabilities(), true);
    }

    /**
     * Capability report payload sent to the hub.
     */
    public static function report(): array
    {
        return [
            'agent_id'           => SiteHub_Auth::getAgentId(),
            'site_url'           => home_url(),
            'agent_version'      => SITEHUB_AGENT_VERSION,
            'capability_version' => '2.1',
            'capabilities'       => self::getAll(),
            'collect_capabilities'    => self::getCollectCapabilities(),
            'management_capabilities' => self::$managementCapabilities,
        ];
    }
}
