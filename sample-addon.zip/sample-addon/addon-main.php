<?php
/*
Plugin Name: Sample Addon
Description: Demonstrates Addon integration with Vira Code Snippet.
Version: 1.0.0
Author: Viraloka Team
Vira-Addon: true
Menu Title: Sample Addon
Menu Slug: vrcode-addon-sample
Addon Active: yes
*/

function vrcode_sample_addon_register_menu() {
    add_submenu_page(
        'vrcode',
        'Sample Addon',
        'Sample Addon',
        'manage_options',
        'vrcode-addon-sample',
        'vrcode_sample_addon_admin_page'
    );
}
add_action('admin_menu', 'vrcode_sample_addon_register_menu', 101);

function vrcode_sample_addon_admin_page() {
    echo '<div class="wrap"><h1>Sample Addon</h1>';
    echo '<div class="vrcode-card" style="max-width:600px;margin:2em auto;padding:2em;text-align:center;">';
    echo '<h2>🎉 This is a Sample Addon!</h2>';
    echo '<p>Welcome to your first Vira Code Addon. You can use this area to build custom features, integrations, or UI tools for your users.</p>';
    echo '<p style="margin-top:2em;"><a href="https://yourmarketplace.com" class="button button-primary" target="_blank">Browse More Addons</a></p>';
    echo '</div></div>';
    // Enqueue main plugin admin CSS for consistency
    echo '<style>.vrcode-card{background:#fff;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,0.06);padding:2em;margin-bottom:2em;}</style>';
} 