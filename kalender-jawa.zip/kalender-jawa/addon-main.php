<?php
/*
Plugin Name: Kalender Jawa
Description: Adds a Kalender Jawa (Javanese Calendar) widget and shortcode to your site.
Version: 1.0.0
Author: Viraloka Team
Vira-Addon: true
Menu Title: Kalender Jawa
Menu Slug: vrcode-addon-kalender-jawa
// Addon Active: yes
*/

// Register shortcode for Kalender Jawa widget
add_action('init', function() {
    add_shortcode('kalender_jawa', 'vrcode_kalender_jawa_shortcode');
});

function vrcode_kalender_jawa_shortcode($atts) {
    // Calculate Javanese date
    $hari = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    $pasaran = ['Legi', 'Pahing', 'Pon', 'Wage', 'Kliwon'];
    $jawa_months = [
        'Sura', 'Sapar', 'Mulud', 'Bakda Mulud', 'Jumadil Awal', 'Jumadil Akhir',
        'Rejeb', 'Ruwah', 'Pasa', 'Sawal', 'Dulkaidah', 'Besar'
    ];
    $base = strtotime('1 January 1936'); // 1 Sura 1868 Jawa, Minggu Legi
    $now = strtotime(date('Y-m-d'));
    $selisih = ($now - $base) / 86400;
    $hari_idx = (int)(($selisih + 0) % 7); // 0: Minggu
    $pasaran_idx = (int)(($selisih + 0) % 5); // 0: Legi
    // Jawa year/month calculation (approximate, for demo)
    $jawa_year = 1868 + floor($selisih / 354.367); // 1 tahun Jawa ~354.367 hari
    $jawa_month = (int)(($selisih / 29.5306) % 12); // 1 bulan Jawa ~29.53 hari
    $jawa_day = (int)(($selisih % 29.5306) + 1);
    ob_start();
    echo '<div class="vrcode-kalender-jawa-widget" style="max-width:340px;margin:1.5em auto;padding:1.5em 1em;background:#fff;border-radius:10px;box-shadow:0 2px 8px rgba(0,0,0,0.06);text-align:center;">';
    echo '<h3 style="margin-top:0;font-size:1.2em;font-weight:600;">Kalender Jawa</h3>';
    echo '<div style="font-size:1.1em;margin:1em 0;">' . esc_html(date('l, d F Y')) . '</div>';
    echo '<div style="font-size:1.08em;margin:0.5em 0 0.7em 0;">'
        . esc_html($hari[$hari_idx]) . ' ' . esc_html($pasaran[$pasaran_idx]) . ', '
        . esc_html($jawa_day) . ' ' . esc_html($jawa_months[$jawa_month]) . ' ' . esc_html($jawa_year) . ' Jawa'
        . '</div>';
    echo '<div style="color:#888;font-size:0.98em;">(Tanggal Jawa dihitung otomatis)</div>';
    echo '</div>';
    return ob_get_clean();
}

// Register Marketplace tab
function vrcode_kalender_jawa_register_marketplace_tab($title, $slug) {
    return [
        'title' => $title,
        'slug' => $slug,
        'callback' => 'vrcode_kalender_jawa_marketplace_tab_content',
    ];
}
add_filter('vrcode_marketplace_addon_tabs', function($tabs) {
    $tabs[] = vrcode_kalender_jawa_register_marketplace_tab('Kalender Jawa', 'vrcode-addon-kalender-jawa');
    return $tabs;
}, 20);

function vrcode_kalender_jawa_marketplace_tab_content() {
    echo '<div class="vrcode-card" style="max-width:600px;margin:2em auto;padding:2em 2.5em;text-align:center;box-shadow:0 2px 12px rgba(0,0,0,0.07);border-radius:12px;background:#fafbfc;">';
    echo '<h2 style="font-weight:600;font-size:1.5em;margin-bottom:0.5em;">📅 Kalender Jawa Widget</h2>';
    echo '<p style="color:#555;font-size:1.08em;margin-bottom:1.5em;">Tampilkan Kalender Jawa di situs Anda dengan mudah. Gunakan shortcode berikut di halaman, posting, atau widget:</p>';
    echo '<code style="display:inline-block;background:#f7fafc;padding:0.5em 1em;border-radius:6px;font-size:1.1em;">[kalender_jawa]</code>';
    echo '<div style="margin:2em 0;">Contoh tampilan:</div>';
    echo vrcode_kalender_jawa_shortcode([]);
    echo '<div style="margin-top:2.5em;color:#888;font-size:0.98em;">Addon ini gratis &amp; open source. Silakan modifikasi sesuai kebutuhan Anda.</div>';
    echo '</div>';
    echo '<style>.vrcode-card{background:#fafbfc;border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,0.07);padding:2em 2.5em;margin-bottom:2em;}</style>';
} 